<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */
//
//ServiceEquipementPhysique 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceEquipementPhysique' => 'Physical Equipment Service',
 'Class:ServiceEquipementPhysique/Attribute:Services_list' => 'Used Services',
 'Class:ServiceEquipementPhysique/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceEquipementPhysique/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceEquipementPhysique' => 'Service Equipement Physique',
 'Class:ServiceEquipementPhysique/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceEquipementPhysique/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceEquipementPhysique/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceEquipementPhysique
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceEquipementPhysiqueToCIs' => 'lnkServiceEquipementPhysique',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceEquipementPhysiqueToServices' => 'Service Relation lnkServiceEquipementPhysique',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceEquipementPhysiqueToCIs' => 'Relation avec CI',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceEquipementPhysiqueToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceEquipementPhysiqueToServices' => 'Relation avec service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceEquipementPhysiqueToServices/Attribute:lnkservice_description' => 'Description',
));

//
//ServiceHebergementPhysique 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceHebergementPhysique' => 'Physical hosting Service',
 'Class:ServiceHebergementPhysique/Attribute:Services_list' => 'Used Services',
 'Class:ServiceHebergementPhysique/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceHebergementPhysique/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceHebergementPhysique' => 'Service Hébergement Physique',
 'Class:ServiceHebergementPhysique/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceHebergementPhysique/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceHebergementPhysique/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceHebergementPhysique
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceHebergementPhysiqueToCIs' => 'lnkServiceHebergementPhysique',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_finalclass' => 'CI class',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceHebergementPhysiqueToCIs' => 'Relation avec CI',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceHebergementPhysiqueToCIs/Attribute:functionalci_finalclass' => 'Class CI',
));

//ServiceOS 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceOS' => 'OS Service',
 'Class:ServiceOS/Attribute:Services_list' => 'Used Services',
 'Class:ServiceOS/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceOS/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceOS' => 'Service OS installé',
 'Class:ServiceOS/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceOS/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceOS/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceOS
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceOSToCIs' => 'lnkServiceOS',
 'Class:lnkServiceOSToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceOSToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceOSToServices' => 'Service Relation lnkServiceOS',
 'Class:lnkServiceOSToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceOSToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceOSToCIs' => 'Relation avec CI',
 'Class:lnkServiceOSToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceOSToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceOSToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceOSToServices' => 'Relation avec service',
 'Class:lnkServiceOSToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceOSToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceOSToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceImpression 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceImpression' => 'Printing Service',
 'Class:ServiceImpression/Attribute:Services_list' => 'Used Services',
 'Class:ServiceImpression/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceImpression/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceImpression' => 'Service Impression',
 'Class:ServiceImpression/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceImpression/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceImpression/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceImpression
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceImpressionToCIs' => 'lnkServiceImpression',
 'Class:lnkServiceImpressionToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceImpressionToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceImpressionToServices' => 'Service Relation lnkServiceImpression',
 'Class:lnkServiceImpressionToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceImpressionToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceImpressionToCIs' => 'Relation avec CI',
 'Class:lnkServiceImpressionToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceImpressionToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceImpressionToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceImpressionToServices' => 'Relation avec service',
 'Class:lnkServiceImpressionToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceImpressionToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceImpressionToServices/Attribute:lnkservice_description' => 'Description',
));
//ServiceVirtualisationMaterielle 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceVirtualisationMaterielle' => 'Hardware Virtualization Service',
 'Class:ServiceVirtualisationMaterielle/Attribute:Services_list' => 'Used Services',
 'Class:ServiceVirtualisationMaterielle/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceVirtualisationMaterielle/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceVirtualisationMaterielle' => 'Service Virtualisation Materielle',
 'Class:ServiceVirtualisationMaterielle/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceVirtualisationMaterielle/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceVirtualisationMaterielle/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceVirtualisationMaterielle
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceVirtualisationMaterielleToCIs' => 'lnkServiceVirtualisationMaterielle',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceVirtualisationMaterielleToServices' => 'Service Relation lnkServiceVirtualisationMaterielle',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceVirtualisationMaterielleToCIs' => 'Relation avec CI',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceVirtualisationMaterielleToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceVirtualisationMaterielleToServices' => 'Relation avec service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceVirtualisationMaterielleToServices/Attribute:lnkservice_description' => 'Description',
));
//ServiceSGBD 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceSGBD' => 'SGBD Service',
 'Class:ServiceSGBD/Attribute:Services_list' => 'Used Services',
 'Class:ServiceSGBD/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceSGBD/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceSGBD' => 'Service SGBD',
 'Class:ServiceSGBD/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceSGBD/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceSGBD/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceSGBD
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceSGBDToCIs' => 'lnkServiceSGBD',
 'Class:lnkServiceSGBDToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceSGBDToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceSGBDToServices' => 'Service Relation lnkServiceSGBD',
 'Class:lnkServiceSGBDToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceSGBDToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceSGBDToCIs' => 'Relation avec CI',
 'Class:lnkServiceSGBDToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceSGBDToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceSGBDToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceSGBDToServices' => 'Relation avec service',
 'Class:lnkServiceSGBDToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceSGBDToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceSGBDToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceInstanceDBB 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceInstanceDBB' => 'DBB Instance Service',
 'Class:ServiceInstanceDBB/Attribute:Services_list' => 'Used Services',
 'Class:ServiceInstanceDBB/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceInstanceDBB/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceInstanceDBB' => 'Service Instance DBB',
 'Class:ServiceInstanceDBB/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceInstanceDBB/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceInstanceDBB/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceInstanceDBB
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceInstanceDBBToCIs' => 'lnkServiceInstanceDBB',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceInstanceDBBToServices' => 'Service Relation lnkServiceInstanceDBB',
 'Class:lnkServiceInstanceDBBToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceInstanceDBBToCIs' => 'Relation avec CI',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceInstanceDBBToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceInstanceDBBToServices' => 'Relation avec service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceInstanceDBBToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceSauvegarde 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceSauvegarde' => 'Backup Service',
 'Class:ServiceSauvegarde/Attribute:Services_list' => 'Used Services',
 'Class:ServiceSauvegarde/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceSauvegarde/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceSauvegarde' => 'Service Sauvegarde',
 'Class:ServiceSauvegarde/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceSauvegarde/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceSauvegarde/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceSauvegarde
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceSauvegardeToCIs' => 'lnkServiceSauvegarde',
 'Class:lnkServiceSauvegardeToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceSauvegardeToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceSauvegardeToServices' => 'Service Relation lnkServiceSauvegarde',
 'Class:lnkServiceSauvegardeToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceSauvegardeToCIs' => 'Relation avec CI',
 'Class:lnkServiceSauvegardeToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceSauvegardeToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceSauvegardeToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceSauvegardeToServices' => 'Relation avec service',
 'Class:lnkServiceSauvegardeToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceSauvegardeToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceStockageExterne 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceStockageExterne' => 'External Storage Service',
 'Class:ServiceStockageExterne/Attribute:Services_list' => 'Used Services',
 'Class:ServiceStockageExterne/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceStockageExterne/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceStockageExterne' => 'Service Stockage Externe',
 'Class:ServiceStockageExterne/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceStockageExterne/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceStockageExterne/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceStockageExterne
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceStockageExterneToCIs' => 'lnkServiceStockageExterne',
 'Class:lnkServiceStockageExterneToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceStockageExterneToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceStockageExterneToServices' => 'Service Relation lnkServiceStockageExterne',
 'Class:lnkServiceStockageExterneToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceStockageExterneToCIs' => 'Relation avec CI',
 'Class:lnkServiceStockageExterneToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceStockageExterneToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceStockageExterneToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceStockageExterneToServices' => 'Relation avec service',
 'Class:lnkServiceStockageExterneToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceStockageExterneToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceHebergement 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceHebergement' => 'Hosting Service',
 'Class:ServiceHebergement/Attribute:Services_list' => 'Used Services',
 'Class:ServiceHebergement/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceHebergement/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceHebergement' => 'Service Hébergement',
 'Class:ServiceHebergement/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceHebergement/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceHebergement/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceHebergement
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceHebergementToCIs' => 'lnkServiceHebergement',
 'Class:lnkServiceHebergementToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceHebergementToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceHebergementToServices' => 'Service Relation lnkServiceHebergement',
 'Class:lnkServiceHebergementToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceHebergementToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceHebergementToCIs' => 'Relation avec CI',
 'Class:lnkServiceHebergementToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceHebergementToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceHebergementToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceHebergementToServices' => 'Relation avec service',
 'Class:lnkServiceHebergementToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceHebergementToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceHebergementToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceServeurApplication 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceServeurApplication' => 'Application Server Service',
 'Class:ServiceServeurApplication/Attribute:Services_list' => 'Used Services',
 'Class:ServiceServeurApplication/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceServeurApplication/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceServeurApplication' => 'Service Serveur d\'Application',
 'Class:ServiceServeurApplication/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceServeurApplication/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceServeurApplication/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceServeurApplication
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceServeurApplicationToCIs' => 'lnkServiceServeurApplication',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceServeurApplicationToServices' => 'Service Relation lnkServiceServeurApplication',
 'Class:lnkServiceServeurApplicationToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceServeurApplicationToCIs' => 'Relation avec CI',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceServeurApplicationToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceServeurApplicationToServices' => 'Relation avec service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceServeurApplicationToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceLicence 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceLicence' => 'Licence Service',
 'Class:ServiceLicence/Attribute:Services_list' => 'Used Services',
 'Class:ServiceLicence/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceLicence/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceLicence' => 'Service de Licence',
 'Class:ServiceLicence/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceLicence/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceLicence/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceLicence
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceLicenceToCIs' => 'lnkServiceLicence',
 'Class:lnkServiceLicenceToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceLicenceToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceLicenceToServices' => 'Service Relation lnkServiceLicence',
 'Class:lnkServiceLicenceToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceLicenceToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceLicenceToCIs' => 'Relation avec CI',
 'Class:lnkServiceLicenceToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceLicenceToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceLicenceToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceLicenceToServices' => 'Relation avec service',
 'Class:lnkServiceLicenceToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceLicenceToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceLicenceToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceEchangeInterApplicatif 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceEchangeInterApplicatif' => 'Inter-application Exchange Service',
 'Class:ServiceEchangeInterApplicatif/Attribute:Services_list' => 'Used Services',
 'Class:ServiceEchangeInterApplicatif/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceEchangeInterApplicatif/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceEchangeInterApplicatif' => 'Service Echange Inter-Applicatif',
 'Class:ServiceEchangeInterApplicatif/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceEchangeInterApplicatif/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceEchangeInterApplicatif/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceEchangeInterApplicatif
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceEchangeInterApplicatifToCIs' => 'lnkServiceEchangeInterApplicatif',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceEchangeInterApplicatifToServices' => 'Service Relation lnkServiceEchangeInterApplicatif',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceEchangeInterApplicatifToCIs' => 'Relation avec CI',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceEchangeInterApplicatifToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceEchangeInterApplicatifToServices' => 'Relation avec service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceEchangeInterApplicatifToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceApplicatif 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceApplicatif' => 'Application Service',
 'Class:ServiceApplicatif/Attribute:Services_list' => 'Used Services',
 'Class:ServiceApplicatif/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceApplicatif/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceApplicatif' => 'Service Applicatif',
 'Class:ServiceApplicatif/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceApplicatif/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceApplicatif/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceApplicatif
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceApplicatifToCIs' => 'lnkServiceApplicatif',
 'Class:lnkServiceApplicatifToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceApplicatifToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceApplicatifToServices' => 'Service Relation lnkServiceApplicatif',
 'Class:lnkServiceApplicatifToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceApplicatifToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceApplicatifToCIs' => 'Relation avec CI',
 'Class:lnkServiceApplicatifToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceApplicatifToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceApplicatifToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceApplicatifToServices' => 'Relation avec service',
 'Class:lnkServiceApplicatifToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceApplicatifToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceApplicatifToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceDeploiementLogiciel 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceDeploiementLogiciel' => 'Software Deployment Service',
 'Class:ServiceDeploiementLogiciel/Attribute:Services_list' => 'Used Services',
 'Class:ServiceDeploiementLogiciel/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceDeploiementLogiciel/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceDeploiementLogiciel' => 'Service de Déploiement Logiciel',
 'Class:ServiceDeploiementLogiciel/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceDeploiementLogiciel/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceDeploiementLogiciel/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceDeploiementLogiciel
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceDeploiementLogicielToCIs' => 'lnkServiceDeploiementLogiciel',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceDeploiementLogicielToServices' => 'Service Relation lnkServiceDeploiementLogiciel',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceDeploiementLogicielToCIs' => 'Relation avec CI',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceDeploiementLogicielToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceDeploiementLogicielToServices' => 'Relation avec service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceDeploiementLogicielToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceClient 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceClient' => 'Client Service',
 'Class:ServiceClient/Attribute:Services_list' => 'Used Services',
 'Class:ServiceClient/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceClient/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceClient' => 'Service Client',
 'Class:ServiceClient/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceClient/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceClient/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceClient
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceClientToCIs' => 'lnkServiceClient',
 'Class:lnkServiceClientToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceClientToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceClientToServices' => 'Service Relation lnkServiceClient',
 'Class:lnkServiceClientToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceClientToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceClientToCIs' => 'Relation avec CI',
 'Class:lnkServiceClientToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceClientToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceClientToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceClientToServices' => 'Relation avec service',
 'Class:lnkServiceClientToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceClientToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceClientToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceAccesUtilisateur 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceAccesUtilisateur' => 'User Access Service',
 'Class:ServiceAccesUtilisateur/Attribute:Services_list' => 'Used Services',
 'Class:ServiceAccesUtilisateur/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceAccesUtilisateur/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceAccesUtilisateur' => 'Service Accés Utilisateur',
 'Class:ServiceAccesUtilisateur/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceAccesUtilisateur/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceAccesUtilisateur/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceAccesUtilisateur
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceAccesUtilisateurToCIs' => 'lnkServiceAccesUtilisateur',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceAccesUtilisateurToServices' => 'Service Relation lnkServiceAccesUtilisateur',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceAccesUtilisateurToCIs' => 'Relation avec CI',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceAccesUtilisateurToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceAccesUtilisateurToServices' => 'Relation avec service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceAccesUtilisateurToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceServeurAccesDistant 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceServeurAccesDistant' => 'Remote Access Server Service',
 'Class:ServiceServeurAccesDistant/Attribute:Services_list' => 'Used Services',
 'Class:ServiceServeurAccesDistant/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceServeurAccesDistant/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceServeurAccesDistant' => 'Service Serveur d\'accés distant',
 'Class:ServiceServeurAccesDistant/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceServeurAccesDistant/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceServeurAccesDistant/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceServeurAccesDistant
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceServeurAccesDistantToCIs' => 'lnkServiceServeurAccesDistant',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceServeurAccesDistantToServices' => 'Service Relation lnkServiceServeurAccesDistant',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceServeurAccesDistantToCIs' => 'Relation avec CI',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceServeurAccesDistantToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceServeurAccesDistantToServices' => 'Relation avec service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceServeurAccesDistantToServices/Attribute:lnkservice_description' => 'Description',
));

//ServiceDeploiementMateriel 
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceDeploiementMateriel' => 'Pre-deployment Service',
 'Class:ServiceDeploiementMateriel/Attribute:Services_list' => 'Used Services',
 'Class:ServiceDeploiementMateriel/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceDeploiementMateriel/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceDeploiementMateriel' => 'Service de Déploiement Materiel',
 'Class:ServiceDeploiementMateriel/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceDeploiementMateriel/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceDeploiementMateriel/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceDeploiementMateriel
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceDeploiementMaterielToCIs' => 'lnkServiceDeploiementMateriel',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceDeploiementMaterielToServices' => 'Service Relation lnkServiceDeploiementMateriel',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_description' => 'Description',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceDeploiementMaterielToCIs' => 'Relation avec CI',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_name' => 'Nom CI',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_description' => 'Description CI',
 'Class:lnkServiceDeploiementMaterielToCIs/Attribute:functionalci_finalclass' => 'Class CI',
 'Class:lnkServiceDeploiementMaterielToServices' => 'Relation avec service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:service_name' => 'Nom Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_name' => 'Nom Service',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_status' => 'Statut',
 'Class:lnkServiceDeploiementMaterielToServices/Attribute:lnkservice_description' => 'Description',
));

//ProviderContract
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ProviderContract/Attribute:Services_list' => 'Services'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ProviderContract/Attribute:Services_list' => 'Services'
));

//
//lnkServiceToProviderContract
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceToProviderContract' => 'Link Service / Provider contract',
 'Class:lnkServiceToProviderContract/Attribute:Service_id' => 'Service',
 'Class:lnkServiceToProviderContract/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceToProviderContract/Attribute:providercontract_id' => 'Provider contract',
 'Class:lnkServiceToProviderContract/Attribute:providercontract_name' => 'Provider contract name',
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:lnkServiceToProviderContract' => 'Relation Service / Contrat fournisseur',
 'Class:lnkServiceToProviderContract/Attribute:Service_id' => 'Service',
 'Class:lnkServiceToProviderContract/Attribute:Service_name' => 'Nom service',
 'Class:lnkServiceToProviderContract/Attribute:providercontract_id' => 'Contrat fournisseur',
 'Class:lnkServiceToProviderContract/Attribute:providercontract_name' => 'Nom Contrat fournisseur',

));

//ServiceControleAcces
 
Dict::Add('EN US', 'English', 'English', array(

 'Class:ServiceControleAcces' => 'Access Control Service',
 'Class:ServiceControleAcces/Attribute:Services_list' => 'Used Services',
 'Class:ServiceControleAcces/Attribute:functionalci_list' => 'Depends on CIs',
 'Class:ServiceControleAcces/Attribute:providercontract_list' => 'Provider contract'
));

Dict::Add('FR FR', 'French', 'Français', array(
 'Class:ServiceControleAcces' => 'Service Contrôle Accès',
 'Class:ServiceControleAcces/Attribute:Services_list' => 'Services utilisés',
 'Class:ServiceControleAcces/Attribute:functionalci_list' => 'Dépend des CIs',
 'Class:ServiceControleAcces/Attribute:providercontract_list' => 'Contracts fournisseurs'
));

//
//lnkServiceControleAcces
 
Dict::Add('EN US', 'English', 'English', array(
 'Class:lnkServiceControleAccesToCIs' => 'lnkServiceControleAcces',
 'Class:lnkServiceControleAccesToCIs/Attribute:Service_id' => 'Service',
 'Class:lnkServiceControleAccesToCIs/Attribute:Service_name' => 'Service name',
 'Class:lnkServiceControleAccesToCIs/Attribute:functionalci_id' => 'CI',
 'Class:lnkServiceControleAccesToCIs/Attribute:functionalci_name' => 'CI name',
 'Class:lnkServiceControleAccesToCIs/Attribute:functionalci_description' => 'CI description',
 'Class:lnkServiceControleAccesToCIs/Attribute:functionalci_finalclass' => 'CI class',
 'Class:lnkServiceControleAccesToServices' => 'Service Relation lnkServiceControleAcces',
 'Class:lnkServiceControleAccesToServices/Attribute:service_id' => 'Service',
 'Class:lnkServiceControleAccesToServices/Attribute:service_name' => 'Service name',
 'Class:lnkServiceControleAccesToServices/Attribute:lnkservice_id' => 'Service',
 'Class:lnkServiceControleAccesToServices/Attribute:lnkservice_name' => 'Service name',
 'Class:lnkServiceControleAccesToServices/Attribute:lnkservice_org_id' => 'Organisation',
 'Class:lnkServiceControleAccesToServices/Attribute:lnkservice_status' => 'Status',
 'Class:lnkServiceControleAccesToServices/Attribute:lnkservice_description' => 'Description',
));




//
//Menu
 
Dict::Add('EN US', 'English', 'English', array(
 'Menu:NewService' => 'New Service',
));

Dict::Add('FR FR', 'French', 'Français', array(
'Menu:NewService' => 'Nouveau Service',
));





?>

 
 
 
