<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

// Dictionary conventions
// Class:<class_name>
// Class:<class_name>+
// Class:<class_name>/Attribute:<attribute_code>
// Class:<class_name>/Attribute:<attribute_code>+
// Class:<class_name>/Attribute:<attribute_code>/Value:<value>
// Class:<class_name>/Attribute:<attribute_code>/Value:<value>+
// Class:<class_name>/Stimulus:<stimulus_code>
// Class:<class_name>/Stimulus:<stimulus_code>+

//////////////////////////////////////////////////////////////////////
// Note: The classes have been grouped by categories: bizmodel
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
// Classes in 'bizmodel'
//////////////////////////////////////////////////////////////////////
//

//
// Class: Attachment
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Attachment' => 'Attachment',
	'Class:Attachment+' => '',
	'Class:Attachment/Attribute:expire' => 'expire',
	'Class:Attachment/Attribute:expire+' => '',
	'Class:Attachment/Attribute:temp_id' => 'temp id',
	'Class:Attachment/Attribute:temp_id+' => '',
	'Class:Attachment/Attribute:item_class' => 'item class',
	'Class:Attachment/Attribute:item_class+' => '',
	'Class:Attachment/Attribute:item_id' => 'item id',
	'Class:Attachment/Attribute:item_id+' => '',
	'Class:Attachment/Attribute:item_org_id' => 'item org id',
	'Class:Attachment/Attribute:item_org_id+' => '',
	'Class:Attachment/Attribute:contents' => 'contents',
	'Class:Attachment/Attribute:contents+' => '',
));

//
// Class: Organization
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Organization' => 'Organization',
	'Class:Organization+' => '',
	'Class:Organization/Attribute:name' => 'Name',
	'Class:Organization/Attribute:name+' => 'Common name',
	'Class:Organization/Attribute:code' => 'Code',
	'Class:Organization/Attribute:code+' => 'Organization code (Siret, DUNS,...)',
	'Class:Organization/Attribute:status' => 'Status',
	'Class:Organization/Attribute:status+' => '',
	'Class:Organization/Attribute:status/Value:active' => 'Active',
	'Class:Organization/Attribute:status/Value:active+' => 'Active',
	'Class:Organization/Attribute:status/Value:inactive' => 'Inactive',
	'Class:Organization/Attribute:status/Value:inactive+' => 'Inactive',
	'Class:Organization/Attribute:parent_id' => 'Parent',
	'Class:Organization/Attribute:parent_id+' => 'Parent organization',
	'Class:Organization/Attribute:parent_name' => 'Parent name',
	'Class:Organization/Attribute:parent_name+' => 'Name of the parent organization',
	'Class:Organization/Attribute:deliverymodel_id' => 'Delivery model',
	'Class:Organization/Attribute:deliverymodel_id+' => '',
	'Class:Organization/Attribute:deliverymodel_name' => 'Delivery model name',
	'Class:Organization/Attribute:deliverymodel_name+' => '',
	'Class:Organization/Attribute:parent_id_friendlyname' => 'Parent',
	'Class:Organization/Attribute:parent_id_friendlyname+' => 'Parent organization',
));

//
// Class: Location
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Location' => 'Location',
	'Class:Location+' => 'Any type of location: Region, Country, City, Site, Building, Floor, Room, Rack,...',
	'Class:Location/Attribute:name' => 'Name',
	'Class:Location/Attribute:name+' => '',
	'Class:Location/Attribute:status' => 'Status',
	'Class:Location/Attribute:status+' => '',
	'Class:Location/Attribute:status/Value:active' => 'Active',
	'Class:Location/Attribute:status/Value:active+' => 'Active',
	'Class:Location/Attribute:status/Value:inactive' => 'Inactive',
	'Class:Location/Attribute:status/Value:inactive+' => 'Inactive',
	'Class:Location/Attribute:org_id' => 'Owner organization',
	'Class:Location/Attribute:org_id+' => '',
	'Class:Location/Attribute:org_name' => 'Name of the owner organization',
	'Class:Location/Attribute:org_name+' => '',
	'Class:Location/Attribute:address' => 'Address',
	'Class:Location/Attribute:address+' => 'Postal address',
	'Class:Location/Attribute:postal_code' => 'Postal code',
	'Class:Location/Attribute:postal_code+' => 'ZIP/Postal code',
	'Class:Location/Attribute:city' => 'City',
	'Class:Location/Attribute:city+' => '',
	'Class:Location/Attribute:country' => 'Country',
	'Class:Location/Attribute:country+' => '',
	'Class:Location/Attribute:physicaldevice_list' => 'Devices',
	'Class:Location/Attribute:physicaldevice_list+' => 'All the devices in this location',
	'Class:Location/Attribute:person_list' => 'Contacts',
	'Class:Location/Attribute:person_list+' => 'All the contacts located on this location',
	'Class:Location/Attribute:finalclass' => 'finalclass',
	'Class:Location/Attribute:finalclass+' => '',
));

//
// Class: Contact
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Contact' => 'Contact',
	'Class:Contact+' => '',
	'Class:Contact/Attribute:name' => 'Name',
	'Class:Contact/Attribute:name+' => '',
	'Class:Contact/Attribute:status' => 'Status',
	'Class:Contact/Attribute:status+' => '',
	'Class:Contact/Attribute:status/Value:active' => 'Active',
	'Class:Contact/Attribute:status/Value:active+' => 'Active',
	'Class:Contact/Attribute:status/Value:inactive' => 'Inactive',
	'Class:Contact/Attribute:status/Value:inactive+' => 'Inactive',
	'Class:Contact/Attribute:org_id' => 'Organization',
	'Class:Contact/Attribute:org_id+' => '',
	'Class:Contact/Attribute:org_name' => 'Organization name',
	'Class:Contact/Attribute:org_name+' => '',
	'Class:Contact/Attribute:email' => 'Email',
	'Class:Contact/Attribute:email+' => '',
	'Class:Contact/Attribute:phone' => 'Phone',
	'Class:Contact/Attribute:phone+' => '',
	'Class:Contact/Attribute:notify' => 'Notification',
	'Class:Contact/Attribute:notify+' => '',
	'Class:Contact/Attribute:notify/Value:no' => 'no',
	'Class:Contact/Attribute:notify/Value:no+' => 'no',
	'Class:Contact/Attribute:notify/Value:yes' => 'yes',
	'Class:Contact/Attribute:notify/Value:yes+' => 'yes',
	'Class:Contact/Attribute:function' => 'Function',
	'Class:Contact/Attribute:function+' => '',
	'Class:Contact/Attribute:cis_list' => 'CIs',
	'Class:Contact/Attribute:cis_list+' => 'All the configuration items linked to this contact',
	'Class:Contact/Attribute:finalclass' => 'Contact Type',
	'Class:Contact/Attribute:finalclass+' => '',
));

//
// Class: Person
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Person' => 'Person',
	'Class:Person+' => '',
	'Class:Person/Attribute:first_name' => 'First Name',
	'Class:Person/Attribute:first_name+' => '',
	'Class:Person/Attribute:employee_number' => 'Employee number',
	'Class:Person/Attribute:employee_number+' => '',
	'Class:Person/Attribute:mobile_phone' => 'Mobile phone',
	'Class:Person/Attribute:mobile_phone+' => '',
	'Class:Person/Attribute:location_id' => 'Location',
	'Class:Person/Attribute:location_id+' => '',
	'Class:Person/Attribute:location_name' => 'Location name',
	'Class:Person/Attribute:location_name+' => '',
	'Class:Person/Attribute:manager_id' => 'Manager',
	'Class:Person/Attribute:manager_id+' => '',
	'Class:Person/Attribute:manager_name' => 'Manager name',
	'Class:Person/Attribute:manager_name+' => '',
	'Class:Person/Attribute:team_list' => 'Teams',
	'Class:Person/Attribute:team_list+' => 'All the teams this person belongs to',
	'Class:Person/Attribute:tickets_list' => 'Tickets',
	'Class:Person/Attribute:tickets_list+' => 'All the tickets this person is the caller',
	'Class:Person/Attribute:manager_id_friendlyname' => 'Manager friendly name',
	'Class:Person/Attribute:manager_id_friendlyname+' => '',
));

//
// Class: Team
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Team' => 'Team',
	'Class:Team+' => '',
	'Class:Team/Attribute:persons_list' => 'Members',
	'Class:Team/Attribute:persons_list+' => 'All the people belonging to this team',
	'Class:Team/Attribute:tickets_list' => 'Tickets',
	'Class:Team/Attribute:tickets_list+' => 'All the tickets assigned to this team',
));

//
// Class: Document
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Document' => 'Document',
	'Class:Document+' => '',
	'Class:Document/Attribute:name' => 'Name',
	'Class:Document/Attribute:name+' => '',
	'Class:Document/Attribute:org_id' => 'Organization',
	'Class:Document/Attribute:org_id+' => '',
	'Class:Document/Attribute:org_name' => 'Organization name',
	'Class:Document/Attribute:org_name+' => '',
	'Class:Document/Attribute:documenttype_id' => 'Document type',
	'Class:Document/Attribute:documenttype_id+' => '',
	'Class:Document/Attribute:documenttype_name' => 'Document type name',
	'Class:Document/Attribute:documenttype_name+' => '',
	'Class:Document/Attribute:version' => 'Version',
	'Class:Document/Attribute:version+' => '',
	'Class:Document/Attribute:description' => 'Description',
	'Class:Document/Attribute:description+' => '',
	'Class:Document/Attribute:status' => 'Status',
	'Class:Document/Attribute:status+' => '',
	'Class:Document/Attribute:status/Value:draft' => 'Draft',
	'Class:Document/Attribute:status/Value:draft+' => '',
	'Class:Document/Attribute:status/Value:obsolete' => 'Obsolete',
	'Class:Document/Attribute:status/Value:obsolete+' => '',
	'Class:Document/Attribute:status/Value:published' => 'Published',
	'Class:Document/Attribute:status/Value:published+' => '',
	'Class:Document/Attribute:cis_list' => 'CIs',
	'Class:Document/Attribute:cis_list+' => 'All the configuration items linked to this document',
	'Class:Document/Attribute:contracts_list' => 'Contracts',
	'Class:Document/Attribute:contracts_list+' => 'All the contracts linked to this document',
	'Class:Document/Attribute:services_list' => 'Services',
	'Class:Document/Attribute:services_list+' => 'All the services linked to this document',
	'Class:Document/Attribute:finalclass' => 'Document Type',
	'Class:Document/Attribute:finalclass+' => '',
));

//
// Class: DocumentFile
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DocumentFile' => 'Document File',
	'Class:DocumentFile+' => '',
	'Class:DocumentFile/Attribute:file' => 'File',
	'Class:DocumentFile/Attribute:file+' => '',
));

//
// Class: DocumentNote
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DocumentNote' => 'Document Note',
	'Class:DocumentNote+' => '',
	'Class:DocumentNote/Attribute:text' => 'Text',
	'Class:DocumentNote/Attribute:text+' => '',
));

//
// Class: DocumentWeb
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DocumentWeb' => 'Document Web',
	'Class:DocumentWeb+' => '',
	'Class:DocumentWeb/Attribute:url' => 'URL',
	'Class:DocumentWeb/Attribute:url+' => '',
));

//
// Class: FunctionalCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:FunctionalCI' => 'Functional CI',
	'Class:FunctionalCI+' => '',
	'Class:FunctionalCI/Attribute:name' => 'Name',
	'Class:FunctionalCI/Attribute:name+' => '',
	'Class:FunctionalCI/Attribute:description' => 'Description',
	'Class:FunctionalCI/Attribute:description+' => '',
	'Class:FunctionalCI/Attribute:org_id' => 'Organization',
	'Class:FunctionalCI/Attribute:org_id+' => '',
	'Class:FunctionalCI/Attribute:organization_name' => 'Organization name',
	'Class:FunctionalCI/Attribute:organization_name+' => 'Common name',
	'Class:FunctionalCI/Attribute:business_criticity' => 'Business criticity',
	'Class:FunctionalCI/Attribute:business_criticity+' => '',
	'Class:FunctionalCI/Attribute:business_criticity/Value:high' => 'high',
	'Class:FunctionalCI/Attribute:business_criticity/Value:high+' => 'high',
	'Class:FunctionalCI/Attribute:business_criticity/Value:low' => 'low',
	'Class:FunctionalCI/Attribute:business_criticity/Value:low+' => 'low',
	'Class:FunctionalCI/Attribute:business_criticity/Value:medium' => 'medium',
	'Class:FunctionalCI/Attribute:business_criticity/Value:medium+' => 'medium',
	'Class:FunctionalCI/Attribute:move2production' => 'Move to production date',
	'Class:FunctionalCI/Attribute:move2production+' => '',
	'Class:FunctionalCI/Attribute:contacts_list' => 'Contacts',
	'Class:FunctionalCI/Attribute:contacts_list+' => 'All the contacts for this configuration item',
	'Class:FunctionalCI/Attribute:documents_list' => 'Documents',
	'Class:FunctionalCI/Attribute:documents_list+' => 'All the documents linked to this configuration item',
	'Class:FunctionalCI/Attribute:applicationsolution_list' => 'Application solutions',
	'Class:FunctionalCI/Attribute:applicationsolution_list+' => 'All the application solutions depending on this configuration item',
	'Class:FunctionalCI/Attribute:providercontracts_list' => 'Provider contracts',
	'Class:FunctionalCI/Attribute:providercontracts_list+' => 'All the provider contracts for this configuration item',
	'Class:FunctionalCI/Attribute:services_list' => 'Services',
	'Class:FunctionalCI/Attribute:services_list+' => 'All the services impacted by this configuration item',
	'Class:FunctionalCI/Attribute:softwares_list' => 'Softwares',
	'Class:FunctionalCI/Attribute:softwares_list+' => 'All the softwares installed on this configuration item',
	'Class:FunctionalCI/Attribute:tickets_list' => 'Tickets',
	'Class:FunctionalCI/Attribute:tickets_list+' => 'All the tickets for this configuration item',
	'Class:FunctionalCI/Attribute:finalclass' => 'CI Type',
	'Class:FunctionalCI/Attribute:finalclass+' => '',
));

//
// Class: PhysicalDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PhysicalDevice' => 'Physical Device',
	'Class:PhysicalDevice+' => '',
	'Class:PhysicalDevice/Attribute:serialnumber' => 'Serial number',
	'Class:PhysicalDevice/Attribute:serialnumber+' => '',
	'Class:PhysicalDevice/Attribute:location_id' => 'Location',
	'Class:PhysicalDevice/Attribute:location_id+' => '',
	'Class:PhysicalDevice/Attribute:location_name' => 'Location name',
	'Class:PhysicalDevice/Attribute:location_name+' => '',
	'Class:PhysicalDevice/Attribute:status' => 'Status',
	'Class:PhysicalDevice/Attribute:status+' => '',
	'Class:PhysicalDevice/Attribute:status/Value:implementation' => 'implementation',
	'Class:PhysicalDevice/Attribute:status/Value:implementation+' => 'implementation',
	'Class:PhysicalDevice/Attribute:status/Value:obsolete' => 'obsolete',
	'Class:PhysicalDevice/Attribute:status/Value:obsolete+' => 'obsolete',
	'Class:PhysicalDevice/Attribute:status/Value:production' => 'production',
	'Class:PhysicalDevice/Attribute:status/Value:production+' => 'production',
	'Class:PhysicalDevice/Attribute:status/Value:stock' => 'stock',
	'Class:PhysicalDevice/Attribute:status/Value:stock+' => 'stock',
	'Class:PhysicalDevice/Attribute:brand_id' => 'Brand',
	'Class:PhysicalDevice/Attribute:brand_id+' => '',
	'Class:PhysicalDevice/Attribute:brand_name' => 'Brand name',
	'Class:PhysicalDevice/Attribute:brand_name+' => '',
	'Class:PhysicalDevice/Attribute:model_id' => 'Model',
	'Class:PhysicalDevice/Attribute:model_id+' => '',
	'Class:PhysicalDevice/Attribute:model_name' => 'Model name',
	'Class:PhysicalDevice/Attribute:model_name+' => '',
	'Class:PhysicalDevice/Attribute:asset_number' => 'Asset number',
	'Class:PhysicalDevice/Attribute:asset_number+' => '',
	'Class:PhysicalDevice/Attribute:purchase_date' => 'Purchase date',
	'Class:PhysicalDevice/Attribute:purchase_date+' => '',
	'Class:PhysicalDevice/Attribute:end_of_warranty' => 'End of warranty',
	'Class:PhysicalDevice/Attribute:end_of_warranty+' => '',
	'Class:PhysicalDevice/Attribute:building_id' => 'Building',
	'Class:PhysicalDevice/Attribute:building_id+' => '',
	'Class:PhysicalDevice/Attribute:building_name' => 'Building name',
	'Class:PhysicalDevice/Attribute:building_name+' => '',
	'Class:PhysicalDevice/Attribute:floor_id' => 'Floor',
	'Class:PhysicalDevice/Attribute:floor_id+' => '',
	'Class:PhysicalDevice/Attribute:floor_name' => 'Floor name',
	'Class:PhysicalDevice/Attribute:floor_name+' => '',
	'Class:PhysicalDevice/Attribute:room_id' => 'Room',
	'Class:PhysicalDevice/Attribute:room_id+' => '',
	'Class:PhysicalDevice/Attribute:room_name' => 'Room name',
	'Class:PhysicalDevice/Attribute:room_name+' => '',
	'Class:PhysicalDevice/Attribute:bay_id' => 'Bay',
	'Class:PhysicalDevice/Attribute:bay_id+' => '',
	'Class:PhysicalDevice/Attribute:bay_name' => 'Bay name',
	'Class:PhysicalDevice/Attribute:bay_name+' => '',
));

//
// Class: ConnectableCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:ConnectableCI' => 'Connectable CI',
	'Class:ConnectableCI+' => 'Physical CI',
	'Class:ConnectableCI/Attribute:networkdevice_list' => 'Network devices',
	'Class:ConnectableCI/Attribute:networkdevice_list+' => 'All network devices connected to this device',
	'Class:ConnectableCI/Attribute:physicalinterface_list' => 'Network interfaces',
	'Class:ConnectableCI/Attribute:physicalinterface_list+' => 'All the physical network interfaces',
));

//
// Class: DatacenterDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DatacenterDevice' => 'Datacenter Device',
	'Class:DatacenterDevice+' => '',
	'Class:DatacenterDevice/Attribute:rack_id' => 'Rack',
	'Class:DatacenterDevice/Attribute:rack_id+' => '',
	'Class:DatacenterDevice/Attribute:rack_name' => 'Rack name',
	'Class:DatacenterDevice/Attribute:rack_name+' => '',
	'Class:DatacenterDevice/Attribute:enclosure_id' => 'Enclosure',
	'Class:DatacenterDevice/Attribute:enclosure_id+' => '',
	'Class:DatacenterDevice/Attribute:enclosure_name' => 'Enclosure name',
	'Class:DatacenterDevice/Attribute:enclosure_name+' => '',
	'Class:DatacenterDevice/Attribute:nb_u' => 'Rack units',
	'Class:DatacenterDevice/Attribute:nb_u+' => '',
	'Class:DatacenterDevice/Attribute:managementip' => 'Management ip',
	'Class:DatacenterDevice/Attribute:managementip+' => '',
	'Class:DatacenterDevice/Attribute:powerA_id' => 'PowerA source',
	'Class:DatacenterDevice/Attribute:powerA_id+' => '',
	'Class:DatacenterDevice/Attribute:powerA_name' => 'PowerA source name',
	'Class:DatacenterDevice/Attribute:powerA_name+' => '',
	'Class:DatacenterDevice/Attribute:powerB_id' => 'PowerB source',
	'Class:DatacenterDevice/Attribute:powerB_id+' => '',
	'Class:DatacenterDevice/Attribute:powerB_name' => 'PowerB source name',
	'Class:DatacenterDevice/Attribute:powerB_name+' => '',
	'Class:DatacenterDevice/Attribute:fiberinterfacelist_list' => 'FC ports',
	'Class:DatacenterDevice/Attribute:fiberinterfacelist_list+' => 'All the fiber channel interfaces for this device',
	'Class:DatacenterDevice/Attribute:san_list' => 'SANs',
	'Class:DatacenterDevice/Attribute:san_list+' => 'All the SAN switches connected to this device',
	'Class:DatacenterDevice/Attribute:redundancy' => 'Redundancy',
	'Class:DatacenterDevice/Attribute:redundancy+' => '',
));

//
// Class: NetworkDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:NetworkDevice' => 'Network Device',
	'Class:NetworkDevice+' => '',
	'Class:NetworkDevice/Attribute:networkdevicetype_id' => 'Network type',
	'Class:NetworkDevice/Attribute:networkdevicetype_id+' => '',
	'Class:NetworkDevice/Attribute:networkdevicetype_name' => 'Network type name',
	'Class:NetworkDevice/Attribute:networkdevicetype_name+' => '',
	'Class:NetworkDevice/Attribute:connectablecis_list' => 'Devices',
	'Class:NetworkDevice/Attribute:connectablecis_list+' => 'All the devices connected to this network device',
	'Class:NetworkDevice/Attribute:iosversion_id' => 'IOS version',
	'Class:NetworkDevice/Attribute:iosversion_id+' => '',
	'Class:NetworkDevice/Attribute:iosversion_name' => 'IOS version name',
	'Class:NetworkDevice/Attribute:iosversion_name+' => '',
	'Class:NetworkDevice/Attribute:ram' => 'RAM',
	'Class:NetworkDevice/Attribute:ram+' => '',
));

//
// Class: Server
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Server' => 'Server',
	'Class:Server+' => '',
	'Class:Server/Attribute:osfamily_id' => 'OS family',
	'Class:Server/Attribute:osfamily_id+' => '',
	'Class:Server/Attribute:osfamily_name' => 'OS family name',
	'Class:Server/Attribute:osfamily_name+' => '',
	'Class:Server/Attribute:osversion_id' => 'OS version',
	'Class:Server/Attribute:osversion_id+' => '',
	'Class:Server/Attribute:osversion_name' => 'OS version name',
	'Class:Server/Attribute:osversion_name+' => '',
	'Class:Server/Attribute:oslicence_id' => 'OS licence',
	'Class:Server/Attribute:oslicence_id+' => '',
	'Class:Server/Attribute:oslicence_name' => 'OS licence name',
	'Class:Server/Attribute:oslicence_name+' => '',
	'Class:Server/Attribute:cpu' => 'CPU',
	'Class:Server/Attribute:cpu+' => '',
	'Class:Server/Attribute:ram' => 'RAM',
	'Class:Server/Attribute:ram+' => '',
	'Class:Server/Attribute:logicalvolumes_list' => 'Logical volumes',
	'Class:Server/Attribute:logicalvolumes_list+' => 'All the logical volumes connected to this server',
	'Class:Server/Attribute:service_list' => 'Services',
	'Class:Server/Attribute:service_list+' => '',
));

//
// Class: ApplicationSolution
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:ApplicationSolution' => 'Application Solution',
	'Class:ApplicationSolution+' => '',
	'Class:ApplicationSolution/Attribute:functionalcis_list' => 'CIs',
	'Class:ApplicationSolution/Attribute:functionalcis_list+' => 'All the configuration items that compose this application solution',
	'Class:ApplicationSolution/Attribute:businessprocess_list' => 'Business processes',
	'Class:ApplicationSolution/Attribute:businessprocess_list+' => 'All the business processes depending on this application solution',
	'Class:ApplicationSolution/Attribute:status' => 'Status',
	'Class:ApplicationSolution/Attribute:status+' => '',
	'Class:ApplicationSolution/Attribute:status/Value:active' => 'active',
	'Class:ApplicationSolution/Attribute:status/Value:active+' => 'active',
	'Class:ApplicationSolution/Attribute:status/Value:inactive' => 'inactive',
	'Class:ApplicationSolution/Attribute:status/Value:inactive+' => 'inactive',
	'Class:ApplicationSolution/Attribute:redundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:redundancy+' => '',
	'Class:ApplicationSolution/Attribute:software_id' => 'Software',
	'Class:ApplicationSolution/Attribute:software_id+' => '',
	'Class:ApplicationSolution/Attribute:software_name' => 'Software name',
	'Class:ApplicationSolution/Attribute:software_name+' => '',
	'Class:ApplicationSolution/Attribute:softwarelicence_id' => 'Software licences',
	'Class:ApplicationSolution/Attribute:softwarelicence_id+' => '',
	'Class:ApplicationSolution/Attribute:softwarelicence_name' => 'Software licence name',
	'Class:ApplicationSolution/Attribute:softwarelicence_name+' => '',
	'Class:ApplicationSolution/Attribute:licencesoftware_list' => 'Licence softwares',
	'Class:ApplicationSolution/Attribute:licencesoftware_list+' => '',
	'Class:ApplicationSolution/Attribute:databaseschema_list' => 'Database schema',
	'Class:ApplicationSolution/Attribute:databaseschema_list+' => '',
	'Class:ApplicationSolution/Attribute:virtualmachine_list' => 'Hosts',
	'Class:ApplicationSolution/Attribute:virtualmachine_list+' => '',
	'Class:ApplicationSolution/Attribute:serversoftware_list' => 'Server softwares',
	'Class:ApplicationSolution/Attribute:serversoftware_list+' => '',
	'Class:ApplicationSolution/Attribute:middlewareinstance_list' => 'Middleware instance',
	'Class:ApplicationSolution/Attribute:middlewareinstance_list+' => '',
	'Class:ApplicationSolution/Attribute:databaseschemaredundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:databaseschemaredundancy+' => '',
	'Class:ApplicationSolution/Attribute:virtualmachineredundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:virtualmachineredundancy+' => '',
	'Class:ApplicationSolution/Attribute:serversoftwareredundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:serversoftwareredundancy+' => '',
	'Class:ApplicationSolution/Attribute:middlewareinstanceredundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:middlewareinstanceredundancy+' => '',
	'Class:ApplicationSolution/Attribute:licenceredundancy' => 'Impact analysis: configuration of the redundancy',
	'Class:ApplicationSolution/Attribute:licenceredundancy+' => '',
	'Class:ApplicationSolution/Attribute:service_list' => 'Services',
	'Class:ApplicationSolution/Attribute:service_list+' => '',
));

//
// Class: BusinessProcess
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:BusinessProcess' => 'Business Process',
	'Class:BusinessProcess+' => '',
	'Class:BusinessProcess/Attribute:applicationsolutions_list' => 'Application solutions',
	'Class:BusinessProcess/Attribute:applicationsolutions_list+' => 'All the application solutions that impact this business process',
	'Class:BusinessProcess/Attribute:status' => 'Status',
	'Class:BusinessProcess/Attribute:status+' => '',
	'Class:BusinessProcess/Attribute:status/Value:active' => 'active',
	'Class:BusinessProcess/Attribute:status/Value:active+' => 'active',
	'Class:BusinessProcess/Attribute:status/Value:inactive' => 'inactive',
	'Class:BusinessProcess/Attribute:status/Value:inactive+' => 'inactive',
	'Class:BusinessProcess/Attribute:pcsoftware_list' => 'PC Software',
	'Class:BusinessProcess/Attribute:pcsoftware_list+' => '',
	'Class:BusinessProcess/Attribute:deportedconsol_list' => 'Deported Consol',
	'Class:BusinessProcess/Attribute:deportedconsol_list+' => '',
	'Class:BusinessProcess/Attribute:service_list' => 'Services',
	'Class:BusinessProcess/Attribute:service_list+' => '',
));

//
// Class: SoftwareInstance
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:SoftwareInstance' => 'Software Instance',
	'Class:SoftwareInstance+' => '',
	'Class:SoftwareInstance/Attribute:system_id' => 'System',
	'Class:SoftwareInstance/Attribute:system_id+' => '',
	'Class:SoftwareInstance/Attribute:system_name' => 'System name',
	'Class:SoftwareInstance/Attribute:system_name+' => '',
	'Class:SoftwareInstance/Attribute:software_id' => 'Software',
	'Class:SoftwareInstance/Attribute:software_id+' => '',
	'Class:SoftwareInstance/Attribute:software_name' => 'Software name',
	'Class:SoftwareInstance/Attribute:software_name+' => '',
	'Class:SoftwareInstance/Attribute:softwarelicence_id' => 'Software licence',
	'Class:SoftwareInstance/Attribute:softwarelicence_id+' => '',
	'Class:SoftwareInstance/Attribute:softwarelicence_name' => 'Software licence name',
	'Class:SoftwareInstance/Attribute:softwarelicence_name+' => '',
	'Class:SoftwareInstance/Attribute:path' => 'Path',
	'Class:SoftwareInstance/Attribute:path+' => '',
	'Class:SoftwareInstance/Attribute:status' => 'Status',
	'Class:SoftwareInstance/Attribute:status+' => '',
	'Class:SoftwareInstance/Attribute:status/Value:active' => 'active',
	'Class:SoftwareInstance/Attribute:status/Value:active+' => 'active',
	'Class:SoftwareInstance/Attribute:status/Value:inactive' => 'inactive',
	'Class:SoftwareInstance/Attribute:status/Value:inactive+' => 'inactive',
	'Class:SoftwareInstance/Attribute:deploymentpackage_list' => 'Deployment package',
	'Class:SoftwareInstance/Attribute:deploymentpackage_list+' => '',
));

//
// Class: Middleware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Middleware' => 'Middleware',
	'Class:Middleware+' => '',
	'Class:Middleware/Attribute:middlewareinstance_list' => 'Middleware instances',
	'Class:Middleware/Attribute:middlewareinstance_list+' => 'All the middleware instances provided by this middleware',
	'Class:Middleware/Attribute:service_list' => 'Services',
	'Class:Middleware/Attribute:service_list+' => '',
));

//
// Class: DBServer
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DBServer' => 'DB Server',
	'Class:DBServer+' => '',
	'Class:DBServer/Attribute:dbschema_list' => 'DB schemas',
	'Class:DBServer/Attribute:dbschema_list+' => 'All the database schemas for this DB server',
	'Class:DBServer/Attribute:dbcluster_id' => 'DB Cluster',
	'Class:DBServer/Attribute:dbcluster_id+' => '',
	'Class:DBServer/Attribute:dbcluster_name' => 'Db Cluster name',
	'Class:DBServer/Attribute:dbcluster_name+' => '',
	'Class:DBServer/Attribute:service_list' => 'Services',
	'Class:DBServer/Attribute:service_list+' => '',
));

//
// Class: WebServer
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:WebServer' => 'Web server',
	'Class:WebServer+' => '',
	'Class:WebServer/Attribute:webapp_list' => 'Web applications',
	'Class:WebServer/Attribute:webapp_list+' => 'All the web applications available on this web server',
	'Class:WebServer/Attribute:service_list' => 'Services',
	'Class:WebServer/Attribute:service_list+' => '',
));

//
// Class: PCSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PCSoftware' => 'PC Software',
	'Class:PCSoftware+' => '',
	'Class:PCSoftware/Attribute:service_list' => 'Services',
	'Class:PCSoftware/Attribute:service_list+' => '',
));

//
// Class: OtherSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:OtherSoftware' => 'Other Software',
	'Class:OtherSoftware+' => '',
));

//
// Class: MiddlewareInstance
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:MiddlewareInstance' => 'Middleware Instance',
	'Class:MiddlewareInstance+' => '',
	'Class:MiddlewareInstance/Attribute:middleware_id' => 'Middleware',
	'Class:MiddlewareInstance/Attribute:middleware_id+' => '',
	'Class:MiddlewareInstance/Attribute:middleware_name' => 'Middleware name',
	'Class:MiddlewareInstance/Attribute:middleware_name+' => '',
	'Class:MiddlewareInstance/Attribute:applicationsol_list' => 'Application Solution',
	'Class:MiddlewareInstance/Attribute:applicationsol_list+' => '',
	'Class:MiddlewareInstance/Attribute:service_list' => 'Services',
	'Class:MiddlewareInstance/Attribute:service_list+' => '',
));

//
// Class: DatabaseSchema
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DatabaseSchema' => 'Database Schema',
	'Class:DatabaseSchema+' => '',
	'Class:DatabaseSchema/Attribute:dbserver_id' => 'DB server',
	'Class:DatabaseSchema/Attribute:dbserver_id+' => '',
	'Class:DatabaseSchema/Attribute:dbserver_name' => 'DB server name',
	'Class:DatabaseSchema/Attribute:dbserver_name+' => '',
	'Class:DatabaseSchema/Attribute:applicationsol_list' => 'Application Solution',
	'Class:DatabaseSchema/Attribute:applicationsol_list+' => '',
	'Class:DatabaseSchema/Attribute:service_list' => 'Services',
	'Class:DatabaseSchema/Attribute:service_list+' => '',
));

//
// Class: WebApplication
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:WebApplication' => 'Web Application',
	'Class:WebApplication+' => '',
	'Class:WebApplication/Attribute:webserver_id' => 'Web server',
	'Class:WebApplication/Attribute:webserver_id+' => '',
	'Class:WebApplication/Attribute:webserver_name' => 'Web server name',
	'Class:WebApplication/Attribute:webserver_name+' => '',
	'Class:WebApplication/Attribute:url' => 'URL',
	'Class:WebApplication/Attribute:url+' => '',
));

//
// Class: Software
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Software' => 'Software',
	'Class:Software+' => '',
	'Class:Software/Attribute:name' => 'Name',
	'Class:Software/Attribute:name+' => '',
	'Class:Software/Attribute:vendor' => 'vendor',
	'Class:Software/Attribute:vendor+' => '',
	'Class:Software/Attribute:version' => 'Version',
	'Class:Software/Attribute:version+' => '',
	'Class:Software/Attribute:documents_list' => 'Documents',
	'Class:Software/Attribute:documents_list+' => 'All the documents linked to this software',
	'Class:Software/Attribute:type' => 'Type',
	'Class:Software/Attribute:type+' => '',
	'Class:Software/Attribute:type/Value:ApplicationSolution' => 'ApplicationSolution',
	'Class:Software/Attribute:type/Value:ApplicationSolution+' => 'ApplicationSolution',
	'Class:Software/Attribute:type/Value:DBCluster' => 'DBCluster',
	'Class:Software/Attribute:type/Value:DBCluster+' => 'DBCluster',
	'Class:Software/Attribute:type/Value:DBServer' => 'DB Server',
	'Class:Software/Attribute:type/Value:DBServer+' => 'DB Server',
	'Class:Software/Attribute:type/Value:DeportedConsol' => 'DeportedConsol',
	'Class:Software/Attribute:type/Value:DeportedConsol+' => 'DeportedConsol',
	'Class:Software/Attribute:type/Value:LicenceSoftware' => 'LicenceSoftware',
	'Class:Software/Attribute:type/Value:LicenceSoftware+' => 'LicenceSoftware',
	'Class:Software/Attribute:type/Value:Middleware' => 'Middleware',
	'Class:Software/Attribute:type/Value:Middleware+' => 'Middleware',
	'Class:Software/Attribute:type/Value:OtherSoftware' => 'Other Software',
	'Class:Software/Attribute:type/Value:OtherSoftware+' => 'Other Software',
	'Class:Software/Attribute:type/Value:PCSoftware' => 'PC Software',
	'Class:Software/Attribute:type/Value:PCSoftware+' => 'PC Software',
	'Class:Software/Attribute:type/Value:ServerSoftware' => 'ServerSoftware',
	'Class:Software/Attribute:type/Value:ServerSoftware+' => 'ServerSoftware',
	'Class:Software/Attribute:type/Value:WebServer' => 'Web Server',
	'Class:Software/Attribute:type/Value:WebServer+' => 'Web Server',
	'Class:Software/Attribute:type/Value:backupSoftware' => 'backupSoftware',
	'Class:Software/Attribute:type/Value:backupSoftware+' => 'backupSoftware',
	'Class:Software/Attribute:softwareinstance_list' => 'Software Instances',
	'Class:Software/Attribute:softwareinstance_list+' => 'All the software instances for this software',
	'Class:Software/Attribute:softwarepatch_list' => 'Software Patches',
	'Class:Software/Attribute:softwarepatch_list+' => 'All the patchs for this software',
	'Class:Software/Attribute:softwarelicence_list' => 'Software Licences',
	'Class:Software/Attribute:softwarelicence_list+' => 'All the licences for this software',
	'Class:Software/Attribute:vendor_name' => 'Name',
	'Class:Software/Attribute:vendor_name+' => '',
));

//
// Class: Patch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Patch' => 'Patch',
	'Class:Patch+' => '',
	'Class:Patch/Attribute:name' => 'Name',
	'Class:Patch/Attribute:name+' => '',
	'Class:Patch/Attribute:documents_list' => 'Documents',
	'Class:Patch/Attribute:documents_list+' => 'All the documents linked to this patch',
	'Class:Patch/Attribute:description' => 'Description',
	'Class:Patch/Attribute:description+' => '',
	'Class:Patch/Attribute:finalclass' => 'Type',
	'Class:Patch/Attribute:finalclass+' => '',
));

//
// Class: OSPatch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:OSPatch' => 'OS Patch',
	'Class:OSPatch+' => '',
	'Class:OSPatch/Attribute:functionalcis_list' => 'Devices',
	'Class:OSPatch/Attribute:functionalcis_list+' => 'All the systems where this patch is installed',
	'Class:OSPatch/Attribute:osversion_id' => 'OS version',
	'Class:OSPatch/Attribute:osversion_id+' => '',
	'Class:OSPatch/Attribute:osversion_name' => 'OS version name',
	'Class:OSPatch/Attribute:osversion_name+' => '',
));

//
// Class: SoftwarePatch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:SoftwarePatch' => 'Software Patch',
	'Class:SoftwarePatch+' => '',
	'Class:SoftwarePatch/Attribute:software_id' => 'Software',
	'Class:SoftwarePatch/Attribute:software_id+' => '',
	'Class:SoftwarePatch/Attribute:software_name' => 'Software name',
	'Class:SoftwarePatch/Attribute:software_name+' => '',
	'Class:SoftwarePatch/Attribute:softwareinstances_list' => 'Software instances',
	'Class:SoftwarePatch/Attribute:softwareinstances_list+' => 'All the systems where this software patch is installed',
));

//
// Class: Licence
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Licence' => 'License',
	'Class:Licence+' => '',
	'Class:Licence/Attribute:name' => 'Name',
	'Class:Licence/Attribute:name+' => '',
	'Class:Licence/Attribute:documents_list' => 'Documents',
	'Class:Licence/Attribute:documents_list+' => 'All the documents linked to this licence',
	'Class:Licence/Attribute:org_id' => 'Organization',
	'Class:Licence/Attribute:org_id+' => '',
	'Class:Licence/Attribute:organization_name' => 'Organization name',
	'Class:Licence/Attribute:organization_name+' => 'Common name',
	'Class:Licence/Attribute:usage_limit' => 'Usage limit',
	'Class:Licence/Attribute:usage_limit+' => '',
	'Class:Licence/Attribute:description' => 'Description',
	'Class:Licence/Attribute:description+' => '',
	'Class:Licence/Attribute:start_date' => 'Start date',
	'Class:Licence/Attribute:start_date+' => '',
	'Class:Licence/Attribute:end_date' => 'End date',
	'Class:Licence/Attribute:end_date+' => '',
	'Class:Licence/Attribute:licence_key' => 'Key',
	'Class:Licence/Attribute:licence_key+' => '',
	'Class:Licence/Attribute:perpetual' => 'Perpetual',
	'Class:Licence/Attribute:perpetual+' => '',
	'Class:Licence/Attribute:perpetual/Value:no' => 'no',
	'Class:Licence/Attribute:perpetual/Value:no+' => 'no',
	'Class:Licence/Attribute:perpetual/Value:yes' => 'yes',
	'Class:Licence/Attribute:perpetual/Value:yes+' => 'yes',
	'Class:Licence/Attribute:finalclass' => 'Type',
	'Class:Licence/Attribute:finalclass+' => '',
));

//
// Class: OSLicence
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:OSLicence' => 'OS Licence',
	'Class:OSLicence+' => '',
	'Class:OSLicence/Attribute:osversion_id' => 'OS version',
	'Class:OSLicence/Attribute:osversion_id+' => '',
	'Class:OSLicence/Attribute:osversion_name' => 'OS version name',
	'Class:OSLicence/Attribute:osversion_name+' => '',
	'Class:OSLicence/Attribute:virtualmachines_list' => 'Virtual machines',
	'Class:OSLicence/Attribute:virtualmachines_list+' => 'All the virtual machines where this licence is used',
	'Class:OSLicence/Attribute:servers_list' => 'servers',
	'Class:OSLicence/Attribute:servers_list+' => 'All the servers where this licence is used',
));

//
// Class: SoftwareLicence
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:SoftwareLicence' => 'Software Licence',
	'Class:SoftwareLicence+' => '',
	'Class:SoftwareLicence/Attribute:software_id' => 'Software',
	'Class:SoftwareLicence/Attribute:software_id+' => '',
	'Class:SoftwareLicence/Attribute:software_name' => 'Software name',
	'Class:SoftwareLicence/Attribute:software_name+' => '',
	'Class:SoftwareLicence/Attribute:softwareinstance_list' => 'Software instances',
	'Class:SoftwareLicence/Attribute:softwareinstance_list+' => 'All the systems where this licence is used',
));

//
// Class: lnkDocumentToLicence
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkDocumentToLicence' => 'Link Document / Licence',
	'Class:lnkDocumentToLicence+' => '',
	'Class:lnkDocumentToLicence/Attribute:licence_id' => 'Licence',
	'Class:lnkDocumentToLicence/Attribute:licence_id+' => '',
	'Class:lnkDocumentToLicence/Attribute:licence_name' => 'Licence name',
	'Class:lnkDocumentToLicence/Attribute:licence_name+' => '',
	'Class:lnkDocumentToLicence/Attribute:document_id' => 'Document',
	'Class:lnkDocumentToLicence/Attribute:document_id+' => '',
	'Class:lnkDocumentToLicence/Attribute:document_name' => 'Document name',
	'Class:lnkDocumentToLicence/Attribute:document_name+' => '',
));

//
// Class: Typology
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Typology' => 'Typology',
	'Class:Typology+' => '',
	'Class:Typology/Attribute:name' => 'Name',
	'Class:Typology/Attribute:name+' => '',
	'Class:Typology/Attribute:finalclass' => 'Type',
	'Class:Typology/Attribute:finalclass+' => '',
));

//
// Class: OSVersion
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:OSVersion' => 'OS Version',
	'Class:OSVersion+' => '',
	'Class:OSVersion/Attribute:osfamily_id' => 'OS family',
	'Class:OSVersion/Attribute:osfamily_id+' => '',
	'Class:OSVersion/Attribute:osfamily_name' => 'OS family name',
	'Class:OSVersion/Attribute:osfamily_name+' => '',
	'Class:OSVersion/Attribute:Server_list' => 'Server list',
	'Class:OSVersion/Attribute:Server_list+' => '',
	'Class:OSVersion/Attribute:Host_list' => 'Host list',
	'Class:OSVersion/Attribute:Host_list+' => '',
	'Class:OSVersion/Attribute:PC_list' => 'PC list',
	'Class:OSVersion/Attribute:PC_list+' => '',
	'Class:OSVersion/Attribute:Licence_list' => 'Licence list',
	'Class:OSVersion/Attribute:Licence_list+' => '',
));

//
// Class: OSFamily
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:OSFamily' => 'OS Family',
	'Class:OSFamily+' => '',
	'Class:OSFamily/Attribute:OSversion_list' => 'OSversion list',
	'Class:OSFamily/Attribute:OSversion_list+' => '',
));

//
// Class: DocumentType
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DocumentType' => 'Document Type',
	'Class:DocumentType+' => '',
));

//
// Class: ContactType
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:ContactType' => 'Contact Type',
	'Class:ContactType+' => '',
));

//
// Class: Brand
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Brand' => 'Brand',
	'Class:Brand+' => '',
	'Class:Brand/Attribute:physicaldevices_list' => 'Physical devices',
	'Class:Brand/Attribute:physicaldevices_list+' => 'All the physical devices corresponding to this brand',
));

//
// Class: Model
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Model' => 'Model',
	'Class:Model+' => '',
	'Class:Model/Attribute:brand_id' => 'Brand',
	'Class:Model/Attribute:brand_id+' => '',
	'Class:Model/Attribute:brand_name' => 'Brand name',
	'Class:Model/Attribute:brand_name+' => '',
	'Class:Model/Attribute:type' => 'Device type',
	'Class:Model/Attribute:type+' => '',
	'Class:Model/Attribute:type/Value:Cooling' => 'Cooling',
	'Class:Model/Attribute:type/Value:Cooling+' => 'Cooling',
	'Class:Model/Attribute:type/Value:DiskArray' => 'Disk Array',
	'Class:Model/Attribute:type/Value:DiskArray+' => 'Disk Array',
	'Class:Model/Attribute:type/Value:Enclosure' => 'Enclosure',
	'Class:Model/Attribute:type/Value:Enclosure+' => 'Enclosure',
	'Class:Model/Attribute:type/Value:IPPhone' => 'IP Phone',
	'Class:Model/Attribute:type/Value:IPPhone+' => 'IP Phone',
	'Class:Model/Attribute:type/Value:MobilePhone' => 'Mobile Phone',
	'Class:Model/Attribute:type/Value:MobilePhone+' => 'Mobile Phone',
	'Class:Model/Attribute:type/Value:NAS' => 'NAS',
	'Class:Model/Attribute:type/Value:NAS+' => 'NAS',
	'Class:Model/Attribute:type/Value:NetworkDevice' => 'Network Device',
	'Class:Model/Attribute:type/Value:NetworkDevice+' => 'Network Device',
	'Class:Model/Attribute:type/Value:PC' => 'PC',
	'Class:Model/Attribute:type/Value:PC+' => 'PC',
	'Class:Model/Attribute:type/Value:PDU' => 'PDU',
	'Class:Model/Attribute:type/Value:PDU+' => 'PDU',
	'Class:Model/Attribute:type/Value:Peripheral' => 'Peripheral',
	'Class:Model/Attribute:type/Value:Peripheral+' => 'Peripheral',
	'Class:Model/Attribute:type/Value:Phone' => 'Telephone',
	'Class:Model/Attribute:type/Value:Phone+' => 'Telephone',
	'Class:Model/Attribute:type/Value:PowerSource' => 'Power Source',
	'Class:Model/Attribute:type/Value:PowerSource+' => 'Power Source',
	'Class:Model/Attribute:type/Value:Printer' => 'Printer',
	'Class:Model/Attribute:type/Value:Printer+' => 'Printer',
	'Class:Model/Attribute:type/Value:Rack' => 'Rack',
	'Class:Model/Attribute:type/Value:Rack+' => 'Rack',
	'Class:Model/Attribute:type/Value:SANSwitch' => 'SAN switch',
	'Class:Model/Attribute:type/Value:SANSwitch+' => 'SAN switch',
	'Class:Model/Attribute:type/Value:Server' => 'Server',
	'Class:Model/Attribute:type/Value:Server+' => 'Server',
	'Class:Model/Attribute:type/Value:StorageSystem' => 'Storage System',
	'Class:Model/Attribute:type/Value:StorageSystem+' => 'Storage System',
	'Class:Model/Attribute:type/Value:Tablet' => 'Tablet',
	'Class:Model/Attribute:type/Value:Tablet+' => 'Tablet',
	'Class:Model/Attribute:type/Value:TapeLibrary' => 'Tape Library',
	'Class:Model/Attribute:type/Value:TapeLibrary+' => 'Tape Library',
	'Class:Model/Attribute:physicaldevices_list' => 'Physical devices',
	'Class:Model/Attribute:physicaldevices_list+' => 'All the physical devices corresponding to this model',
));

//
// Class: NetworkDeviceType
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:NetworkDeviceType' => 'Network Device Type',
	'Class:NetworkDeviceType+' => '',
	'Class:NetworkDeviceType/Attribute:networkdevicesdevices_list' => 'Network devices',
	'Class:NetworkDeviceType/Attribute:networkdevicesdevices_list+' => 'All the network devices corresponding to this type',
));

//
// Class: IOSVersion
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:IOSVersion' => 'IOS Version',
	'Class:IOSVersion+' => '',
	'Class:IOSVersion/Attribute:brand_id' => 'Brand',
	'Class:IOSVersion/Attribute:brand_id+' => '',
	'Class:IOSVersion/Attribute:brand_name' => 'Brand name',
	'Class:IOSVersion/Attribute:brand_name+' => '',
));

//
// Class: lnkDocumentToPatch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkDocumentToPatch' => 'Link Document / Patch',
	'Class:lnkDocumentToPatch+' => '',
	'Class:lnkDocumentToPatch/Attribute:patch_id' => 'Patch',
	'Class:lnkDocumentToPatch/Attribute:patch_id+' => '',
	'Class:lnkDocumentToPatch/Attribute:patch_name' => 'Patch name',
	'Class:lnkDocumentToPatch/Attribute:patch_name+' => '',
	'Class:lnkDocumentToPatch/Attribute:document_id' => 'Document',
	'Class:lnkDocumentToPatch/Attribute:document_id+' => '',
	'Class:lnkDocumentToPatch/Attribute:document_name' => 'Document name',
	'Class:lnkDocumentToPatch/Attribute:document_name+' => '',
));

//
// Class: lnkSoftwareInstanceToSoftwarePatch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkSoftwareInstanceToSoftwarePatch' => 'Link Software Instance / Software Patch',
	'Class:lnkSoftwareInstanceToSoftwarePatch+' => '',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwarepatch_id' => 'Software patch',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwarepatch_id+' => '',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwarepatch_name' => 'Software patch name',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwarepatch_name+' => '',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwareinstance_id' => 'Software instance',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwareinstance_id+' => '',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwareinstance_name' => 'Software instance name',
	'Class:lnkSoftwareInstanceToSoftwarePatch/Attribute:softwareinstance_name+' => '',
));

//
// Class: lnkFunctionalCIToOSPatch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkFunctionalCIToOSPatch' => 'Link FunctionalCI / OS patch',
	'Class:lnkFunctionalCIToOSPatch+' => '',
	'Class:lnkFunctionalCIToOSPatch/Attribute:ospatch_id' => 'OS patch',
	'Class:lnkFunctionalCIToOSPatch/Attribute:ospatch_id+' => '',
	'Class:lnkFunctionalCIToOSPatch/Attribute:ospatch_name' => 'OS patch name',
	'Class:lnkFunctionalCIToOSPatch/Attribute:ospatch_name+' => '',
	'Class:lnkFunctionalCIToOSPatch/Attribute:functionalci_id' => 'Functionalci',
	'Class:lnkFunctionalCIToOSPatch/Attribute:functionalci_id+' => '',
	'Class:lnkFunctionalCIToOSPatch/Attribute:functionalci_name' => 'Functionalci name',
	'Class:lnkFunctionalCIToOSPatch/Attribute:functionalci_name+' => '',
));

//
// Class: lnkDocumentToSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkDocumentToSoftware' => 'Link Document / Software',
	'Class:lnkDocumentToSoftware+' => '',
	'Class:lnkDocumentToSoftware/Attribute:software_id' => 'Software',
	'Class:lnkDocumentToSoftware/Attribute:software_id+' => '',
	'Class:lnkDocumentToSoftware/Attribute:software_name' => 'Software name',
	'Class:lnkDocumentToSoftware/Attribute:software_name+' => '',
	'Class:lnkDocumentToSoftware/Attribute:document_id' => 'Document',
	'Class:lnkDocumentToSoftware/Attribute:document_id+' => '',
	'Class:lnkDocumentToSoftware/Attribute:document_name' => 'Document name',
	'Class:lnkDocumentToSoftware/Attribute:document_name+' => '',
));

//
// Class: lnkContactToFunctionalCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkContactToFunctionalCI' => 'Link Contact / FunctionalCI',
	'Class:lnkContactToFunctionalCI+' => '',
	'Class:lnkContactToFunctionalCI/Attribute:functionalci_id' => 'Functionalci',
	'Class:lnkContactToFunctionalCI/Attribute:functionalci_id+' => '',
	'Class:lnkContactToFunctionalCI/Attribute:functionalci_name' => 'Functionalci name',
	'Class:lnkContactToFunctionalCI/Attribute:functionalci_name+' => '',
	'Class:lnkContactToFunctionalCI/Attribute:contact_id' => 'Contact',
	'Class:lnkContactToFunctionalCI/Attribute:contact_id+' => '',
	'Class:lnkContactToFunctionalCI/Attribute:contact_name' => 'Contact name',
	'Class:lnkContactToFunctionalCI/Attribute:contact_name+' => '',
));

//
// Class: NetworkInterface
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:NetworkInterface' => 'Network Interface',
	'Class:NetworkInterface+' => '',
	'Class:NetworkInterface/Attribute:name' => 'Name',
	'Class:NetworkInterface/Attribute:name+' => '',
	'Class:NetworkInterface/Attribute:finalclass' => 'Type',
	'Class:NetworkInterface/Attribute:finalclass+' => '',
));

//
// Class: IPInterface
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:IPInterface' => 'IP Interface',
	'Class:IPInterface+' => '',
	'Class:IPInterface/Attribute:ipaddress' => 'IP address',
	'Class:IPInterface/Attribute:ipaddress+' => '',
	'Class:IPInterface/Attribute:macaddress' => 'MAC address',
	'Class:IPInterface/Attribute:macaddress+' => '',
	'Class:IPInterface/Attribute:comment' => 'Comment',
	'Class:IPInterface/Attribute:comment+' => '',
	'Class:IPInterface/Attribute:ipgateway' => 'IP gateway',
	'Class:IPInterface/Attribute:ipgateway+' => '',
	'Class:IPInterface/Attribute:ipmask' => 'IP mask',
	'Class:IPInterface/Attribute:ipmask+' => '',
	'Class:IPInterface/Attribute:speed' => 'Speed',
	'Class:IPInterface/Attribute:speed+' => '',
));

//
// Class: PhysicalInterface
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PhysicalInterface' => 'Physical Interface',
	'Class:PhysicalInterface+' => '',
	'Class:PhysicalInterface/Attribute:connectableci_id' => 'Device',
	'Class:PhysicalInterface/Attribute:connectableci_id+' => '',
	'Class:PhysicalInterface/Attribute:connectableci_name' => 'Device name',
	'Class:PhysicalInterface/Attribute:connectableci_name+' => '',
	'Class:PhysicalInterface/Attribute:vlans_list' => 'VLANs',
	'Class:PhysicalInterface/Attribute:vlans_list+' => '',
));

//
// Class: lnkPhysicalInterfaceToVLAN
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkPhysicalInterfaceToVLAN' => 'Link PhysicalInterface / VLAN',
	'Class:lnkPhysicalInterfaceToVLAN+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_id' => 'Physical Interface',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_id+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_name' => 'Physical Interface Name',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_name+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_device_id' => 'Device',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_device_id+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_device_name' => 'Device name',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:physicalinterface_device_name+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:vlan_id' => 'VLAN',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:vlan_id+' => '',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:vlan_tag' => 'VLAN Tag',
	'Class:lnkPhysicalInterfaceToVLAN/Attribute:vlan_tag+' => '',
));

//
// Class: lnkConnectableCIToNetworkDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkConnectableCIToNetworkDevice' => 'Link ConnectableCI / NetworkDevice',
	'Class:lnkConnectableCIToNetworkDevice+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:networkdevice_id' => 'Network device',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:networkdevice_id+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:networkdevice_name' => 'Network device name',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:networkdevice_name+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connectableci_id' => 'Connected device',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connectableci_id+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connectableci_name' => 'Connected device name',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connectableci_name+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:network_port' => 'Network port',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:network_port+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:device_port' => 'Device port',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:device_port+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type' => 'Connection type',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type+' => '',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type/Value:downlink' => 'down link',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type/Value:downlink+' => 'down link',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type/Value:uplink' => 'up link',
	'Class:lnkConnectableCIToNetworkDevice/Attribute:connection_type/Value:uplink+' => 'up link',
));

//
// Class: lnkApplicationSolutionToFunctionalCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToFunctionalCI' => 'Link ApplicationSolution / FunctionalCI',
	'Class:lnkApplicationSolutionToFunctionalCI+' => '',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:functionalci_id' => 'Functionalci',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:functionalci_id+' => '',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:functionalci_name' => 'Functionalci name',
	'Class:lnkApplicationSolutionToFunctionalCI/Attribute:functionalci_name+' => '',
));

//
// Class: lnkApplicationSolutionToBusinessProcess
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToBusinessProcess' => 'Link ApplicationSolution / BusinessProcess',
	'Class:lnkApplicationSolutionToBusinessProcess+' => '',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:businessprocess_id' => 'Business process',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:businessprocess_id+' => '',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:businessprocess_name' => 'Business process name',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:businessprocess_name+' => '',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToBusinessProcess/Attribute:applicationsolution_name+' => '',
));

//
// Class: lnkPersonToTeam
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkPersonToTeam' => 'Link Person / Team',
	'Class:lnkPersonToTeam+' => '',
	'Class:lnkPersonToTeam/Attribute:team_id' => 'Team',
	'Class:lnkPersonToTeam/Attribute:team_id+' => '',
	'Class:lnkPersonToTeam/Attribute:team_name' => 'Team name',
	'Class:lnkPersonToTeam/Attribute:team_name+' => '',
	'Class:lnkPersonToTeam/Attribute:person_id' => 'Person',
	'Class:lnkPersonToTeam/Attribute:person_id+' => '',
	'Class:lnkPersonToTeam/Attribute:person_name' => 'Person name',
	'Class:lnkPersonToTeam/Attribute:person_name+' => '',
	'Class:lnkPersonToTeam/Attribute:role_id' => 'Role',
	'Class:lnkPersonToTeam/Attribute:role_id+' => '',
	'Class:lnkPersonToTeam/Attribute:role_name' => 'Role name',
	'Class:lnkPersonToTeam/Attribute:role_name+' => '',
));

//
// Class: Group
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Group' => 'Group',
	'Class:Group+' => '',
	'Class:Group/Attribute:name' => 'Name',
	'Class:Group/Attribute:name+' => '',
	'Class:Group/Attribute:status' => 'Status',
	'Class:Group/Attribute:status+' => '',
	'Class:Group/Attribute:status/Value:implementation' => 'Implementation',
	'Class:Group/Attribute:status/Value:implementation+' => 'Implementation',
	'Class:Group/Attribute:status/Value:obsolete' => 'Obsolete',
	'Class:Group/Attribute:status/Value:obsolete+' => 'Obsolete',
	'Class:Group/Attribute:status/Value:production' => 'Production',
	'Class:Group/Attribute:status/Value:production+' => 'Production',
	'Class:Group/Attribute:org_id' => 'Organization',
	'Class:Group/Attribute:org_id+' => '',
	'Class:Group/Attribute:owner_name' => 'Name',
	'Class:Group/Attribute:owner_name+' => 'Common name',
	'Class:Group/Attribute:description' => 'Description',
	'Class:Group/Attribute:description+' => '',
	'Class:Group/Attribute:type' => 'Type',
	'Class:Group/Attribute:type+' => '',
	'Class:Group/Attribute:parent_id' => 'Parent Group',
	'Class:Group/Attribute:parent_id+' => '',
	'Class:Group/Attribute:parent_name' => 'Name',
	'Class:Group/Attribute:parent_name+' => '',
	'Class:Group/Attribute:ci_list' => 'Linked CIs',
	'Class:Group/Attribute:ci_list+' => 'All the configuration items linked to this group',
	'Class:Group/Attribute:parent_id_friendlyname' => 'Parent Group',
	'Class:Group/Attribute:parent_id_friendlyname+' => '',
));

//
// Class: lnkGroupToCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkGroupToCI' => 'Link Group / CI',
	'Class:lnkGroupToCI+' => '',
	'Class:lnkGroupToCI/Attribute:group_id' => 'Group',
	'Class:lnkGroupToCI/Attribute:group_id+' => '',
	'Class:lnkGroupToCI/Attribute:group_name' => 'Name',
	'Class:lnkGroupToCI/Attribute:group_name+' => '',
	'Class:lnkGroupToCI/Attribute:ci_id' => 'CI',
	'Class:lnkGroupToCI/Attribute:ci_id+' => '',
	'Class:lnkGroupToCI/Attribute:ci_name' => 'Name',
	'Class:lnkGroupToCI/Attribute:ci_name+' => '',
	'Class:lnkGroupToCI/Attribute:reason' => 'Reason',
	'Class:lnkGroupToCI/Attribute:reason+' => '',
));

//
// Class: Rack
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Rack' => 'Rack',
	'Class:Rack+' => '',
	'Class:Rack/Attribute:nb_u' => 'Rack units',
	'Class:Rack/Attribute:nb_u+' => '',
	'Class:Rack/Attribute:device_list' => 'Devices',
	'Class:Rack/Attribute:device_list+' => 'All the physical devices racked into this rack',
	'Class:Rack/Attribute:enclosure_list' => 'Enclosures',
	'Class:Rack/Attribute:enclosure_list+' => 'All the enclosures in this rack',
	'Class:Rack/Attribute:service_list' => 'service list',
	'Class:Rack/Attribute:service_list+' => '',
));

//
// Class: Enclosure
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Enclosure' => 'Enclosure',
	'Class:Enclosure+' => '',
	'Class:Enclosure/Attribute:rack_id' => 'Rack',
	'Class:Enclosure/Attribute:rack_id+' => '',
	'Class:Enclosure/Attribute:rack_name' => 'Rack name',
	'Class:Enclosure/Attribute:rack_name+' => '',
	'Class:Enclosure/Attribute:nb_u' => 'Rack units',
	'Class:Enclosure/Attribute:nb_u+' => '',
	'Class:Enclosure/Attribute:device_list' => 'Devices',
	'Class:Enclosure/Attribute:device_list+' => 'All the devices in this enclosure',
));

//
// Class: PowerConnection
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PowerConnection' => 'Power Connection',
	'Class:PowerConnection+' => '',
));

//
// Class: PowerSource
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PowerSource' => 'Power Source',
	'Class:PowerSource+' => '',
	'Class:PowerSource/Attribute:pdus_list' => 'PDUs',
	'Class:PowerSource/Attribute:pdus_list+' => 'All the PDUs using this power source',
));

//
// Class: PDU
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PDU' => 'PDU',
	'Class:PDU+' => '',
	'Class:PDU/Attribute:rack_id' => 'Rack',
	'Class:PDU/Attribute:rack_id+' => '',
	'Class:PDU/Attribute:rack_name' => 'Rack name',
	'Class:PDU/Attribute:rack_name+' => '',
	'Class:PDU/Attribute:powerstart_id' => 'Power start',
	'Class:PDU/Attribute:powerstart_id+' => '',
	'Class:PDU/Attribute:powerstart_name' => 'Power start name',
	'Class:PDU/Attribute:powerstart_name+' => '',
));

//
// Class: PC
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:PC' => 'PC',
	'Class:PC+' => '',
	'Class:PC/Attribute:osfamily_id' => 'OS family',
	'Class:PC/Attribute:osfamily_id+' => '',
	'Class:PC/Attribute:osfamily_name' => 'OS family name',
	'Class:PC/Attribute:osfamily_name+' => '',
	'Class:PC/Attribute:osversion_id' => 'OS version',
	'Class:PC/Attribute:osversion_id+' => '',
	'Class:PC/Attribute:osversion_name' => 'OS version name',
	'Class:PC/Attribute:osversion_name+' => '',
	'Class:PC/Attribute:cpu' => 'CPU',
	'Class:PC/Attribute:cpu+' => '',
	'Class:PC/Attribute:ram' => 'RAM',
	'Class:PC/Attribute:ram+' => '',
	'Class:PC/Attribute:type' => 'Type',
	'Class:PC/Attribute:type+' => '',
	'Class:PC/Attribute:type/Value:desktop' => 'desktop',
	'Class:PC/Attribute:type/Value:desktop+' => 'desktop',
	'Class:PC/Attribute:type/Value:laptop' => 'laptop',
	'Class:PC/Attribute:type/Value:laptop+' => 'laptop',
	'Class:PC/Attribute:service_list' => 'Services',
	'Class:PC/Attribute:service_list+' => '',
));

//
// Class: Printer
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Printer' => 'Printer',
	'Class:Printer+' => '',
	'Class:Printer/Attribute:service_list' => 'service list',
	'Class:Printer/Attribute:service_list+' => '',
));

//
// Class: TelephonyCI
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:TelephonyCI' => 'Telephony CI',
	'Class:TelephonyCI+' => '',
	'Class:TelephonyCI/Attribute:phonenumber' => 'Phone number',
	'Class:TelephonyCI/Attribute:phonenumber+' => '',
	'Class:TelephonyCI/Attribute:service_list' => 'service list',
	'Class:TelephonyCI/Attribute:service_list+' => '',
));

//
// Class: Phone
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Phone' => 'Phone',
	'Class:Phone+' => '',
));

//
// Class: MobilePhone
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:MobilePhone' => 'Mobile Phone',
	'Class:MobilePhone+' => '',
	'Class:MobilePhone/Attribute:imei' => 'IMEI',
	'Class:MobilePhone/Attribute:imei+' => '',
	'Class:MobilePhone/Attribute:hw_pin' => 'Hardware PIN',
	'Class:MobilePhone/Attribute:hw_pin+' => '',
));

//
// Class: IPPhone
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:IPPhone' => 'IP Phone',
	'Class:IPPhone+' => '',
));

//
// Class: Tablet
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Tablet' => 'Tablet',
	'Class:Tablet+' => '',
	'Class:Tablet/Attribute:service_list' => 'Services',
	'Class:Tablet/Attribute:service_list+' => '',
));

//
// Class: Peripheral
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Peripheral' => 'Peripheral',
	'Class:Peripheral+' => '',
	'Class:Peripheral/Attribute:service_list' => 'Services',
	'Class:Peripheral/Attribute:service_list+' => '',
));

//
// Class: StorageSystem
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:StorageSystem' => 'Storage System',
	'Class:StorageSystem+' => '',
	'Class:StorageSystem/Attribute:logicalvolume_list' => 'Logical volumes',
	'Class:StorageSystem/Attribute:logicalvolume_list+' => 'All the logical volumes in this storage system',
	'Class:StorageSystem/Attribute:service_list' => 'Services',
	'Class:StorageSystem/Attribute:service_list+' => '',
));

//
// Class: SANSwitch
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:SANSwitch' => 'SAN Switch',
	'Class:SANSwitch+' => '',
	'Class:SANSwitch/Attribute:datacenterdevice_list' => 'Devices',
	'Class:SANSwitch/Attribute:datacenterdevice_list+' => 'All the devices connected to this SAN switch',
));

//
// Class: TapeLibrary
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:TapeLibrary' => 'Tape Library',
	'Class:TapeLibrary+' => '',
	'Class:TapeLibrary/Attribute:tapes_list' => 'Tapes',
	'Class:TapeLibrary/Attribute:tapes_list+' => 'All the tapes in the tape library',
	'Class:TapeLibrary/Attribute:service_list' => 'Services',
	'Class:TapeLibrary/Attribute:service_list+' => '',
));

//
// Class: NAS
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:NAS' => 'NAS',
	'Class:NAS+' => '',
	'Class:NAS/Attribute:nasfilesystem_list' => 'Filesystems',
	'Class:NAS/Attribute:nasfilesystem_list+' => 'All the file systems in this NAS',
	'Class:NAS/Attribute:service_list' => 'Services',
	'Class:NAS/Attribute:service_list+' => '',
));

//
// Class: FiberChannelInterface
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:FiberChannelInterface' => 'Fiber Channel Interface',
	'Class:FiberChannelInterface+' => '',
	'Class:FiberChannelInterface/Attribute:speed' => 'Speed',
	'Class:FiberChannelInterface/Attribute:speed+' => '',
	'Class:FiberChannelInterface/Attribute:topology' => 'Topology',
	'Class:FiberChannelInterface/Attribute:topology+' => '',
	'Class:FiberChannelInterface/Attribute:wwn' => 'WWN',
	'Class:FiberChannelInterface/Attribute:wwn+' => '',
	'Class:FiberChannelInterface/Attribute:datacenterdevice_id' => 'Device',
	'Class:FiberChannelInterface/Attribute:datacenterdevice_id+' => '',
	'Class:FiberChannelInterface/Attribute:datacenterdevice_name' => 'Device name',
	'Class:FiberChannelInterface/Attribute:datacenterdevice_name+' => '',
));

//
// Class: Tape
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Tape' => 'Tape',
	'Class:Tape+' => '',
	'Class:Tape/Attribute:name' => 'Name',
	'Class:Tape/Attribute:name+' => '',
	'Class:Tape/Attribute:description' => 'Description',
	'Class:Tape/Attribute:description+' => '',
	'Class:Tape/Attribute:size' => 'Size',
	'Class:Tape/Attribute:size+' => '',
	'Class:Tape/Attribute:tapelibrary_id' => 'Tape library',
	'Class:Tape/Attribute:tapelibrary_id+' => '',
	'Class:Tape/Attribute:tapelibrary_name' => 'Tape library name',
	'Class:Tape/Attribute:tapelibrary_name+' => '',
));

//
// Class: NASFileSystem
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:NASFileSystem' => 'NAS File System',
	'Class:NASFileSystem+' => '',
	'Class:NASFileSystem/Attribute:name' => 'Name',
	'Class:NASFileSystem/Attribute:name+' => '',
	'Class:NASFileSystem/Attribute:description' => 'Description',
	'Class:NASFileSystem/Attribute:description+' => '',
	'Class:NASFileSystem/Attribute:raid_level' => 'Raid level',
	'Class:NASFileSystem/Attribute:raid_level+' => '',
	'Class:NASFileSystem/Attribute:size' => 'Size',
	'Class:NASFileSystem/Attribute:size+' => '',
	'Class:NASFileSystem/Attribute:nas_id' => 'NAS',
	'Class:NASFileSystem/Attribute:nas_id+' => '',
	'Class:NASFileSystem/Attribute:nas_name' => 'NAS name',
	'Class:NASFileSystem/Attribute:nas_name+' => '',
	'Class:NASFileSystem/Attribute:storage' => 'Storage type',
	'Class:NASFileSystem/Attribute:storage+' => '',
	'Class:NASFileSystem/Attribute:storage/Value:nas' => 'NAS',
	'Class:NASFileSystem/Attribute:storage/Value:nas+' => 'NAS',
	'Class:NASFileSystem/Attribute:storage/Value:storagesystem' => 'Storage system',
	'Class:NASFileSystem/Attribute:storage/Value:storagesystem+' => 'Storage system',
	'Class:NASFileSystem/Attribute:storagesystem_id' => 'Storage system',
	'Class:NASFileSystem/Attribute:storagesystem_id+' => '',
	'Class:NASFileSystem/Attribute:storagesystem_name' => 'Storage system name',
	'Class:NASFileSystem/Attribute:storagesystem_name+' => '',
	'Class:NASFileSystem/Attribute:logicalvolume_id' => 'Logical volume',
	'Class:NASFileSystem/Attribute:logicalvolume_id+' => '',
	'Class:NASFileSystem/Attribute:logicalvolume_name' => 'Logical volume name',
	'Class:NASFileSystem/Attribute:logicalvolume_name+' => '',
	'Class:NASFileSystem/Attribute:service_list' => 'Services',
	'Class:NASFileSystem/Attribute:service_list+' => '',
));

//
// Class: LogicalVolume
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:LogicalVolume' => 'Logical Volume',
	'Class:LogicalVolume+' => '',
	'Class:LogicalVolume/Attribute:name' => 'Name',
	'Class:LogicalVolume/Attribute:name+' => '',
	'Class:LogicalVolume/Attribute:lun_id' => 'LUN ID',
	'Class:LogicalVolume/Attribute:lun_id+' => '',
	'Class:LogicalVolume/Attribute:description' => 'Description',
	'Class:LogicalVolume/Attribute:description+' => '',
	'Class:LogicalVolume/Attribute:raid_level' => 'Raid level',
	'Class:LogicalVolume/Attribute:raid_level+' => '',
	'Class:LogicalVolume/Attribute:size' => 'Size',
	'Class:LogicalVolume/Attribute:size+' => '',
	'Class:LogicalVolume/Attribute:storagesystem_id' => 'Storage system',
	'Class:LogicalVolume/Attribute:storagesystem_id+' => '',
	'Class:LogicalVolume/Attribute:storagesystem_name' => 'Storage system name',
	'Class:LogicalVolume/Attribute:storagesystem_name+' => '',
	'Class:LogicalVolume/Attribute:servers_list' => 'Servers',
	'Class:LogicalVolume/Attribute:servers_list+' => 'All the servers using this volume',
	'Class:LogicalVolume/Attribute:virtualdevices_list' => 'Virtual devices',
	'Class:LogicalVolume/Attribute:virtualdevices_list+' => 'All the virtual devices using this volume',
));

//
// Class: lnkServerToVolume
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkServerToVolume' => 'Link Server / Volume',
	'Class:lnkServerToVolume+' => '',
	'Class:lnkServerToVolume/Attribute:volume_id' => 'Volume',
	'Class:lnkServerToVolume/Attribute:volume_id+' => '',
	'Class:lnkServerToVolume/Attribute:volume_name' => 'Volume name',
	'Class:lnkServerToVolume/Attribute:volume_name+' => '',
	'Class:lnkServerToVolume/Attribute:server_id' => 'Server',
	'Class:lnkServerToVolume/Attribute:server_id+' => '',
	'Class:lnkServerToVolume/Attribute:server_name' => 'Server name',
	'Class:lnkServerToVolume/Attribute:server_name+' => '',
	'Class:lnkServerToVolume/Attribute:size_used' => 'Size used',
	'Class:lnkServerToVolume/Attribute:size_used+' => '',
));

//
// Class: lnkSanToDatacenterDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkSanToDatacenterDevice' => 'Link SAN / Datacenter Device',
	'Class:lnkSanToDatacenterDevice+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:san_id' => 'SAN switch',
	'Class:lnkSanToDatacenterDevice/Attribute:san_id+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:san_name' => 'SAN switch name',
	'Class:lnkSanToDatacenterDevice/Attribute:san_name+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_id' => 'Device',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_id+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_name' => 'Device name',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_name+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:san_port' => 'SAN fc',
	'Class:lnkSanToDatacenterDevice/Attribute:san_port+' => '',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_port' => 'Device fc',
	'Class:lnkSanToDatacenterDevice/Attribute:datacenterdevice_port+' => '',
));

//
// Class: Ticket
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Ticket' => 'Ticket',
	'Class:Ticket+' => '',
	'Class:Ticket/Attribute:ref' => 'Ref',
	'Class:Ticket/Attribute:ref+' => '',
	'Class:Ticket/Attribute:org_id' => 'Organization',
	'Class:Ticket/Attribute:org_id+' => '',
	'Class:Ticket/Attribute:org_name' => 'Organization Name',
	'Class:Ticket/Attribute:org_name+' => '',
	'Class:Ticket/Attribute:caller_id' => 'Caller',
	'Class:Ticket/Attribute:caller_id+' => '',
	'Class:Ticket/Attribute:caller_name' => 'Caller Name',
	'Class:Ticket/Attribute:caller_name+' => '',
	'Class:Ticket/Attribute:team_id' => 'Team',
	'Class:Ticket/Attribute:team_id+' => '',
	'Class:Ticket/Attribute:team_name' => 'Team Name',
	'Class:Ticket/Attribute:team_name+' => '',
	'Class:Ticket/Attribute:agent_id' => 'Agent',
	'Class:Ticket/Attribute:agent_id+' => '',
	'Class:Ticket/Attribute:agent_name' => 'Agent Name',
	'Class:Ticket/Attribute:agent_name+' => '',
	'Class:Ticket/Attribute:title' => 'Title',
	'Class:Ticket/Attribute:title+' => '',
	'Class:Ticket/Attribute:description' => 'Description',
	'Class:Ticket/Attribute:description+' => '',
	'Class:Ticket/Attribute:start_date' => 'Start date',
	'Class:Ticket/Attribute:start_date+' => '',
	'Class:Ticket/Attribute:end_date' => 'End date',
	'Class:Ticket/Attribute:end_date+' => '',
	'Class:Ticket/Attribute:last_update' => 'Last update',
	'Class:Ticket/Attribute:last_update+' => '',
	'Class:Ticket/Attribute:close_date' => 'Close date',
	'Class:Ticket/Attribute:close_date+' => '',
	'Class:Ticket/Attribute:private_log' => 'Private log',
	'Class:Ticket/Attribute:private_log+' => '',
	'Class:Ticket/Attribute:contacts_list' => 'Contacts',
	'Class:Ticket/Attribute:contacts_list+' => 'All the contacts linked to this ticket',
	'Class:Ticket/Attribute:functionalcis_list' => 'CIs',
	'Class:Ticket/Attribute:functionalcis_list+' => 'All the configuration items impacted by this ticket. Items marked as "Computed" have been automatically marked as impacted. Items marked as "Not impacted" are excluded from the impact.',
	'Class:Ticket/Attribute:workorders_list' => 'Work orders',
	'Class:Ticket/Attribute:workorders_list+' => 'All the work orders for this ticket',
	'Class:Ticket/Attribute:finalclass' => 'Type',
	'Class:Ticket/Attribute:finalclass+' => '',
));

//
// Class: lnkContactToTicket
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkContactToTicket' => 'Link Contact / Ticket',
	'Class:lnkContactToTicket+' => '',
	'Class:lnkContactToTicket/Attribute:ticket_id' => 'Ticket',
	'Class:lnkContactToTicket/Attribute:ticket_id+' => '',
	'Class:lnkContactToTicket/Attribute:ticket_ref' => 'Ref',
	'Class:lnkContactToTicket/Attribute:ticket_ref+' => '',
	'Class:lnkContactToTicket/Attribute:contact_id' => 'Contact',
	'Class:lnkContactToTicket/Attribute:contact_id+' => '',
	'Class:lnkContactToTicket/Attribute:contact_email' => 'Contact Email',
	'Class:lnkContactToTicket/Attribute:contact_email+' => '',
	'Class:lnkContactToTicket/Attribute:role' => 'Role (text)',
	'Class:lnkContactToTicket/Attribute:role+' => '',
	'Class:lnkContactToTicket/Attribute:role_code' => 'Role',
	'Class:lnkContactToTicket/Attribute:role_code+' => '',
	'Class:lnkContactToTicket/Attribute:role_code/Value:computed' => 'Computed',
	'Class:lnkContactToTicket/Attribute:role_code/Value:computed+' => 'Computed',
	'Class:lnkContactToTicket/Attribute:role_code/Value:do_not_notify' => 'Do not notify',
	'Class:lnkContactToTicket/Attribute:role_code/Value:do_not_notify+' => 'Do not notify',
	'Class:lnkContactToTicket/Attribute:role_code/Value:manual' => 'Added manually',
	'Class:lnkContactToTicket/Attribute:role_code/Value:manual+' => 'Added manually',
));

//
// Class: lnkFunctionalCIToTicket
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkFunctionalCIToTicket' => 'Link FunctionalCI / Ticket',
	'Class:lnkFunctionalCIToTicket+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_id' => 'Ticket',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_id+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_ref' => 'Ref',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_ref+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_title' => 'Title',
	'Class:lnkFunctionalCIToTicket/Attribute:ticket_title+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:functionalci_id' => 'CI',
	'Class:lnkFunctionalCIToTicket/Attribute:functionalci_id+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:functionalci_name' => 'CI Name',
	'Class:lnkFunctionalCIToTicket/Attribute:functionalci_name+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:impact' => 'Impact (text)',
	'Class:lnkFunctionalCIToTicket/Attribute:impact+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code' => 'Impact',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code+' => '',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:computed' => 'Computed',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:computed+' => 'Computed',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:manual' => 'Added manually',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:manual+' => 'Added manually',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:not_impacted' => 'Not impacted',
	'Class:lnkFunctionalCIToTicket/Attribute:impact_code/Value:not_impacted+' => 'Not impacted',
));

//
// Class: WorkOrder
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:WorkOrder' => 'Work Order',
	'Class:WorkOrder+' => '',
	'Class:WorkOrder/Attribute:name' => 'Name',
	'Class:WorkOrder/Attribute:name+' => '',
	'Class:WorkOrder/Attribute:status' => 'Status',
	'Class:WorkOrder/Attribute:status+' => '',
	'Class:WorkOrder/Attribute:status/Value:open' => 'open',
	'Class:WorkOrder/Attribute:status/Value:open+' => '',
	'Class:WorkOrder/Attribute:status/Value:closed' => 'closed',
	'Class:WorkOrder/Attribute:status/Value:closed+' => '',
	'Class:WorkOrder/Attribute:description' => 'Description',
	'Class:WorkOrder/Attribute:description+' => '',
	'Class:WorkOrder/Attribute:ticket_id' => 'Ticket',
	'Class:WorkOrder/Attribute:ticket_id+' => '',
	'Class:WorkOrder/Attribute:ticket_ref' => 'Ticket ref',
	'Class:WorkOrder/Attribute:ticket_ref+' => '',
	'Class:WorkOrder/Attribute:team_id' => 'Team',
	'Class:WorkOrder/Attribute:team_id+' => '',
	'Class:WorkOrder/Attribute:team_name' => 'Team Name',
	'Class:WorkOrder/Attribute:team_name+' => '',
	'Class:WorkOrder/Attribute:agent_id' => 'Agent',
	'Class:WorkOrder/Attribute:agent_id+' => '',
	'Class:WorkOrder/Attribute:agent_email' => 'Agent email',
	'Class:WorkOrder/Attribute:agent_email+' => '',
	'Class:WorkOrder/Attribute:start_date' => 'Start date',
	'Class:WorkOrder/Attribute:start_date+' => '',
	'Class:WorkOrder/Attribute:end_date' => 'End date',
	'Class:WorkOrder/Attribute:end_date+' => '',
	'Class:WorkOrder/Attribute:log' => 'Log',
	'Class:WorkOrder/Attribute:log+' => '',
	'Class:WorkOrder/Stimulus:ev_close' => 'Close',
	'Class:WorkOrder/Stimulus:ev_close+' => '',
));

//
// Class: VirtualDevice
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:VirtualDevice' => 'Virtual Device',
	'Class:VirtualDevice+' => '',
	'Class:VirtualDevice/Attribute:status' => 'Status',
	'Class:VirtualDevice/Attribute:status+' => '',
	'Class:VirtualDevice/Attribute:status/Value:implementation' => 'implementation',
	'Class:VirtualDevice/Attribute:status/Value:implementation+' => 'implementation',
	'Class:VirtualDevice/Attribute:status/Value:obsolete' => 'obsolete',
	'Class:VirtualDevice/Attribute:status/Value:obsolete+' => 'obsolete',
	'Class:VirtualDevice/Attribute:status/Value:production' => 'production',
	'Class:VirtualDevice/Attribute:status/Value:production+' => 'production',
	'Class:VirtualDevice/Attribute:status/Value:stock' => 'stock',
	'Class:VirtualDevice/Attribute:status/Value:stock+' => 'stock',
	'Class:VirtualDevice/Attribute:logicalvolumes_list' => 'Logical volumes',
	'Class:VirtualDevice/Attribute:logicalvolumes_list+' => 'All the logical volumes used by this device',
));

//
// Class: VirtualHost
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:VirtualHost' => 'Virtual Host',
	'Class:VirtualHost+' => '',
	'Class:VirtualHost/Attribute:virtualmachine_list' => 'Virtual machines',
	'Class:VirtualHost/Attribute:virtualmachine_list+' => 'All the virtual machines hosted by this host',
));

//
// Class: Hypervisor
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Hypervisor' => 'Hypervisor',
	'Class:Hypervisor+' => '',
	'Class:Hypervisor/Attribute:farm_id' => 'Farm',
	'Class:Hypervisor/Attribute:farm_id+' => '',
	'Class:Hypervisor/Attribute:farm_name' => 'Farm name',
	'Class:Hypervisor/Attribute:farm_name+' => '',
	'Class:Hypervisor/Attribute:server_id' => 'Server',
	'Class:Hypervisor/Attribute:server_id+' => '',
	'Class:Hypervisor/Attribute:server_name' => 'Server name',
	'Class:Hypervisor/Attribute:server_name+' => '',
	'Class:Hypervisor/Attribute:service_list' => 'Services',
	'Class:Hypervisor/Attribute:service_list+' => '',
));

//
// Class: Farm
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Farm' => 'Farm',
	'Class:Farm+' => '',
	'Class:Farm/Attribute:hypervisor_list' => 'Hypervisors',
	'Class:Farm/Attribute:hypervisor_list+' => 'All the hypervisors that compose this farm',
	'Class:Farm/Attribute:redundancy' => 'High availability',
	'Class:Farm/Attribute:redundancy+' => '',
	'Class:Farm/Attribute:service_list' => 'Services',
	'Class:Farm/Attribute:service_list+' => '',
));

//
// Class: VirtualMachine
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:VirtualMachine' => 'Virtual Machine',
	'Class:VirtualMachine+' => '',
	'Class:VirtualMachine/Attribute:virtualhost_id' => 'Virtual host',
	'Class:VirtualMachine/Attribute:virtualhost_id+' => '',
	'Class:VirtualMachine/Attribute:virtualhost_name' => 'Virtual host name',
	'Class:VirtualMachine/Attribute:virtualhost_name+' => '',
	'Class:VirtualMachine/Attribute:osfamily_id' => 'OS family',
	'Class:VirtualMachine/Attribute:osfamily_id+' => '',
	'Class:VirtualMachine/Attribute:osfamily_name' => 'OS family name',
	'Class:VirtualMachine/Attribute:osfamily_name+' => '',
	'Class:VirtualMachine/Attribute:osversion_id' => 'OS version',
	'Class:VirtualMachine/Attribute:osversion_id+' => '',
	'Class:VirtualMachine/Attribute:osversion_name' => 'OS version name',
	'Class:VirtualMachine/Attribute:osversion_name+' => '',
	'Class:VirtualMachine/Attribute:oslicence_id' => 'OS licence',
	'Class:VirtualMachine/Attribute:oslicence_id+' => '',
	'Class:VirtualMachine/Attribute:oslicence_name' => 'OS licence name',
	'Class:VirtualMachine/Attribute:oslicence_name+' => '',
	'Class:VirtualMachine/Attribute:cpu' => 'CPU',
	'Class:VirtualMachine/Attribute:cpu+' => '',
	'Class:VirtualMachine/Attribute:ram' => 'RAM',
	'Class:VirtualMachine/Attribute:ram+' => '',
	'Class:VirtualMachine/Attribute:logicalinterface_list' => 'Network Interfaces',
	'Class:VirtualMachine/Attribute:logicalinterface_list+' => 'All the logical network interfaces',
	'Class:VirtualMachine/Attribute:managementip' => 'IP',
	'Class:VirtualMachine/Attribute:managementip+' => '',
	'Class:VirtualMachine/Attribute:nasfilesystem_id' => 'File System',
	'Class:VirtualMachine/Attribute:nasfilesystem_id+' => '',
	'Class:VirtualMachine/Attribute:nasfilesystem_name' => 'File System name',
	'Class:VirtualMachine/Attribute:nasfilesystem_name+' => '',
	'Class:VirtualMachine/Attribute:applicationsol_list' => 'Application solution',
	'Class:VirtualMachine/Attribute:applicationsol_list+' => '',
	'Class:VirtualMachine/Attribute:service_list' => 'Services',
	'Class:VirtualMachine/Attribute:service_list+' => '',
));

//
// Class: LogicalInterface
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:LogicalInterface' => 'Logical Interface',
	'Class:LogicalInterface+' => '',
	'Class:LogicalInterface/Attribute:virtualmachine_id' => 'Virtual machine',
	'Class:LogicalInterface/Attribute:virtualmachine_id+' => '',
	'Class:LogicalInterface/Attribute:virtualmachine_name' => 'Virtual machine name',
	'Class:LogicalInterface/Attribute:virtualmachine_name+' => '',
));

//
// Class: Building
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Building' => 'Building',
	'Class:Building+' => '',
	'Class:Building/Attribute:location_id' => 'location',
	'Class:Building/Attribute:location_id+' => '',
	'Class:Building/Attribute:location_name' => 'Location Name',
	'Class:Building/Attribute:location_name+' => '',
));

//
// Class: Floor
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Floor' => 'Floor',
	'Class:Floor+' => '',
	'Class:Floor/Attribute:building_id' => 'Building',
	'Class:Floor/Attribute:building_id+' => '',
	'Class:Floor/Attribute:building_name' => 'Building Name',
	'Class:Floor/Attribute:building_name+' => '',
));

//
// Class: Room
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Room' => 'Room',
	'Class:Room+' => '',
	'Class:Room/Attribute:floor_id' => 'Floor',
	'Class:Room/Attribute:floor_id+' => '',
	'Class:Room/Attribute:floor_name' => 'Floor Name',
	'Class:Room/Attribute:floor_name+' => '',
));

//
// Class: Bay
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Bay' => 'Bay',
	'Class:Bay+' => '',
	'Class:Bay/Attribute:room_id' => 'Room',
	'Class:Bay/Attribute:room_id+' => '',
	'Class:Bay/Attribute:room_name' => 'Room Name',
	'Class:Bay/Attribute:room_name+' => '',
));

//
// Class: Cooling
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Cooling' => 'Cooling',
	'Class:Cooling+' => '',
	'Class:Cooling/Attribute:averagetemp' => 'Average temperature',
	'Class:Cooling/Attribute:averagetemp+' => '',
	'Class:Cooling/Attribute:averagehumidity' => 'Average humidity',
	'Class:Cooling/Attribute:averagehumidity+' => '',
	'Class:Cooling/Attribute:type' => 'type',
	'Class:Cooling/Attribute:type+' => '',
	'Class:Cooling/Attribute:type/Value:Aircooling' => 'Aircooling',
	'Class:Cooling/Attribute:type/Value:Aircooling+' => 'Aircooling',
	'Class:Cooling/Attribute:type/Value:Watercooling' => 'Watercooling',
	'Class:Cooling/Attribute:type/Value:Watercooling+' => 'Watercooling',
	'Class:Cooling/Attribute:rack_list' => 'Rack list',
	'Class:Cooling/Attribute:rack_list+' => '',
	'Class:Cooling/Attribute:service_list' => 'Services',
	'Class:Cooling/Attribute:service_list+' => '',
));

//
// Class: LicenceSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:LicenceSoftware' => 'Licence software',
	'Class:LicenceSoftware+' => '',
	'Class:LicenceSoftware/Attribute:applicationsol_list' => 'Application solution',
	'Class:LicenceSoftware/Attribute:applicationsol_list+' => '',
	'Class:LicenceSoftware/Attribute:service_list' => 'Services',
	'Class:LicenceSoftware/Attribute:service_list+' => '',
));

//
// Class: ServerSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:ServerSoftware' => 'Server Software',
	'Class:ServerSoftware+' => '',
	'Class:ServerSoftware/Attribute:applicationsol_list' => 'Application solution',
	'Class:ServerSoftware/Attribute:applicationsol_list+' => '',
	'Class:ServerSoftware/Attribute:service_list' => 'Services',
	'Class:ServerSoftware/Attribute:service_list+' => '',
));

//
// Class: backupSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:backupSoftware' => 'Backup software',
	'Class:backupSoftware+' => '',
));

//
// Class: DBCluster
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DBCluster' => 'DB Cluster',
	'Class:DBCluster+' => '',
	'Class:DBCluster/Attribute:dbserver_list' => 'DB Server list',
	'Class:DBCluster/Attribute:dbserver_list+' => '',
	'Class:DBCluster/Attribute:redundancy' => 'Redundancy',
	'Class:DBCluster/Attribute:redundancy+' => '',
	'Class:DBCluster/Attribute:service_list' => 'Services',
	'Class:DBCluster/Attribute:service_list+' => '',
));

//
// Class: DeportedConsol
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DeportedConsol' => 'Deported Consol',
	'Class:DeportedConsol+' => '',
	'Class:DeportedConsol/Attribute:service_list' => 'Services',
	'Class:DeportedConsol/Attribute:service_list+' => '',
));

//
// Class: DeploymentPackage
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:DeploymentPackage' => 'Deployment Package',
	'Class:DeploymentPackage+' => '',
	'Class:DeploymentPackage/Attribute:package_list' => 'Packages',
	'Class:DeploymentPackage/Attribute:package_list+' => '',
	'Class:DeploymentPackage/Attribute:softwareinstance_list' => 'Software instance',
	'Class:DeploymentPackage/Attribute:softwareinstance_list+' => '',
	'Class:DeploymentPackage/Attribute:status' => 'Status',
	'Class:DeploymentPackage/Attribute:status+' => '',
	'Class:DeploymentPackage/Attribute:status/Value:active' => 'active',
	'Class:DeploymentPackage/Attribute:status/Value:active+' => 'active',
	'Class:DeploymentPackage/Attribute:status/Value:inactive' => 'inactive',
	'Class:DeploymentPackage/Attribute:status/Value:inactive+' => 'inactive',
));

//
// Class: Editor
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Editor' => 'Editor',
	'Class:Editor+' => '',
	'Class:Editor/Attribute:email' => 'email',
	'Class:Editor/Attribute:email+' => '',
	'Class:Editor/Attribute:phone' => 'phone',
	'Class:Editor/Attribute:phone+' => '',
	'Class:Editor/Attribute:website' => 'website',
	'Class:Editor/Attribute:website+' => '',
	'Class:Editor/Attribute:adress' => 'adress',
	'Class:Editor/Attribute:adress+' => '',
));

//
// Class: Package
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:Package' => 'Package',
	'Class:Package+' => '',
	'Class:Package/Attribute:name' => 'name',
	'Class:Package/Attribute:name+' => '',
	'Class:Package/Attribute:version' => 'version',
	'Class:Package/Attribute:version+' => '',
	'Class:Package/Attribute:documents_list' => 'Documents',
	'Class:Package/Attribute:documents_list+' => '',
	'Class:Package/Attribute:type' => 'type',
	'Class:Package/Attribute:type+' => '',
	'Class:Package/Attribute:type/Value:PackageApplicatif' => 'Application Package',
	'Class:Package/Attribute:type/Value:PackageApplicatif+' => 'Application Package',
	'Class:Package/Attribute:type/Value:PackageDeConfiguration' => 'Configuration Package',
	'Class:Package/Attribute:type/Value:PackageDeConfiguration+' => 'Configuration Package',
	'Class:Package/Attribute:type/Value:PackageVM' => 'PackageVM',
	'Class:Package/Attribute:type/Value:PackageVM+' => 'PackageVM',
	'Class:Package/Attribute:deploymentpackage_list' => 'Deployment packages',
	'Class:Package/Attribute:deploymentpackage_list+' => '',
));

//
// Class: lnkPackageToDeploymentPackage
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkPackageToDeploymentPackage' => 'Link Package / Deployment package ',
	'Class:lnkPackageToDeploymentPackage+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_id' =>  'Deployment package',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_id+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_name' => 'Deployment package name',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_name+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_id' => 'Package',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_id+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_name' => 'Package name',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_name+' => '',
));

//
// Class: lnkRackToCooling
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkRackToCooling' => 'Link Rack / Cooling',
	'Class:lnkRackToCooling+' => '',
	'Class:lnkRackToCooling/Attribute:rack_id' => 'Rack',
	'Class:lnkRackToCooling/Attribute:rack_id+' => '',
	'Class:lnkRackToCooling/Attribute:rack_name' => 'Rack name',
	'Class:lnkRackToCooling/Attribute:rack_name+' => '',
	'Class:lnkRackToCooling/Attribute:cooling_id' => 'Cooling',
	'Class:lnkRackToCooling/Attribute:cooling_id+' => '',
	'Class:lnkRackToCooling/Attribute:cooling_name' => 'Cooling name',
	'Class:lnkRackToCooling/Attribute:cooling_name+' => '',
));

//
// Class: lnkApplicationSolutionToLicenceSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToLicenceSoftware' => 'Link Application solution / Licence software',
	'Class:lnkApplicationSolutionToLicenceSoftware+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_id' => 'Licence software',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_id+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_name' => 'Licence software name',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_name+' => '',
));

//
// Class: lnkApplicationSolutionToDatabaseSchema
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToDatabaseSchema' => 'Link Application solution / Database schema',
	'Class:lnkApplicationSolutionToDatabaseSchema+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_id' => 'Database schema',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_id+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_name' => 'Database schema name',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_name+' => '',
));

//
// Class: lnkApplicationSolutionToVirtualMachine
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToVirtualMachine' => 'Link Application solution / Host',
	'Class:lnkApplicationSolutionToVirtualMachine+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_id' => 'Host',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_id+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_name' => 'Host name',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_name+' => '',
));

//
// Class: lnkApplicationSolutionToServerSoftware
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToServerSoftware' => 'Link Application solution / Server software',
	'Class:lnkApplicationSolutionToServerSoftware+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_id' => 'Server software',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_id+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_name' => 'Server software name',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_name+' => '',
));

//
// Class: lnkApplicationSolutionToMiddlewareInstance
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkApplicationSolutionToMiddlewareInstance' => 'Link Application solution / Middleware instance',
	'Class:lnkApplicationSolutionToMiddlewareInstance+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_id' => 'Application solution',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_name' => 'Application solution name',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_id' => 'Middleware instance',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_id+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_name' => 'Middleware instance name',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_name+' => '',
));

//
// Class: lnkSoftwareInstanceToDeploymentPackage
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkSoftwareInstanceToDeploymentPackage' => 'Link Software instance / Deployment package',
	'Class:lnkSoftwareInstanceToDeploymentPackage+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_id' => 'Software instance',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_id+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_name' => 'Software instance name',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_name+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_id' => 'Deployment package',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_id+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_name' => 'Deployment package name',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_name+' => '',
));

//
// Class: lnkPCSoftwareToBusinessProcess
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkPCSoftwareToBusinessProcess' => 'Link PC Software / Business Process',
	'Class:lnkPCSoftwareToBusinessProcess+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_id' => 'Business Process',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_id+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_name' => 'Business Process name',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_name+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_id' => 'PC Software',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_id+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_name' => 'PC Software name',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_name+' => '',
));

//
// Class: lnkDeportedConsolToBusinessProcess
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkDeportedConsolToBusinessProcess' => 'Link Deported Consol / Business Process',
	'Class:lnkDeportedConsolToBusinessProcess+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_id' => 'Business Process',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_id+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_name' => 'Business Process name',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_name+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_id' => 'Deported Consol',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_id+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_name' => 'Deported Consol name',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_name+' => '',
));

//
// Class: lnkVirtualDeviceToVolume
//

Dict::Add('EN US', 'English', 'English', array(
	'Class:lnkVirtualDeviceToVolume' => 'Link Virtual Device / Volume',
	'Class:lnkVirtualDeviceToVolume+' => '',
	'Class:lnkVirtualDeviceToVolume/Attribute:volume_id' => 'Volume',
	'Class:lnkVirtualDeviceToVolume/Attribute:volume_id+' => '',
	'Class:lnkVirtualDeviceToVolume/Attribute:volume_name' => 'Volume name',
	'Class:lnkVirtualDeviceToVolume/Attribute:volume_name+' => '',
	'Class:lnkVirtualDeviceToVolume/Attribute:virtualdevice_id' => 'Virtual device',
	'Class:lnkVirtualDeviceToVolume/Attribute:virtualdevice_id+' => '',
	'Class:lnkVirtualDeviceToVolume/Attribute:virtualdevice_name' => 'Virtual device name',
	'Class:lnkVirtualDeviceToVolume/Attribute:virtualdevice_name+' => '',
	'Class:lnkVirtualDeviceToVolume/Attribute:size_used' => 'Size used',
	'Class:lnkVirtualDeviceToVolume/Attribute:size_used+' => '',
));

///////////////////////////////////
///////////////////////////////////

//
// Class: PhysicalDevice
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:PhysicalDevice' => 'Matériel physique',
	'Class:PhysicalDevice+' => '',
	'Class:PhysicalDevice/Attribute:serialnumber' => 'Numéro de série',
	'Class:PhysicalDevice/Attribute:serialnumber+' => '',
	'Class:PhysicalDevice/Attribute:location_id' => 'Site',
	'Class:PhysicalDevice/Attribute:location_id+' => '',
	'Class:PhysicalDevice/Attribute:location_name' => 'Nom site',
	'Class:PhysicalDevice/Attribute:location_name+' => '',
	'Class:PhysicalDevice/Attribute:status' => 'Statut',
	'Class:PhysicalDevice/Attribute:status+' => '',
	'Class:PhysicalDevice/Attribute:status/Value:implementation' => 'implémentation',
	'Class:PhysicalDevice/Attribute:status/Value:implementation+' => 'implémentation',
	'Class:PhysicalDevice/Attribute:status/Value:obsolete' => 'obsolète',
	'Class:PhysicalDevice/Attribute:status/Value:obsolete+' => 'obsolète',
	'Class:PhysicalDevice/Attribute:status/Value:production' => 'production',
	'Class:PhysicalDevice/Attribute:status/Value:production+' => 'production',
	'Class:PhysicalDevice/Attribute:status/Value:stock' => 'stock',
	'Class:PhysicalDevice/Attribute:status/Value:stock+' => 'stock',
	'Class:PhysicalDevice/Attribute:brand_id' => 'Marque',
	'Class:PhysicalDevice/Attribute:brand_id+' => '',
	'Class:PhysicalDevice/Attribute:brand_name' => 'Nom Marque',
	'Class:PhysicalDevice/Attribute:brand_name+' => '',
	'Class:PhysicalDevice/Attribute:model_id' => 'Modèle',
	'Class:PhysicalDevice/Attribute:model_id+' => '',
	'Class:PhysicalDevice/Attribute:model_name' => 'Nom Modèle',
	'Class:PhysicalDevice/Attribute:model_name+' => '',
	'Class:PhysicalDevice/Attribute:asset_number' => 'Numéro Asset',
	'Class:PhysicalDevice/Attribute:asset_number+' => '',
	'Class:PhysicalDevice/Attribute:purchase_date' => 'Date d\'achat',
	'Class:PhysicalDevice/Attribute:purchase_date+' => '',
	'Class:PhysicalDevice/Attribute:end_of_warranty' => 'Date de fin de garantie',
	'Class:PhysicalDevice/Attribute:end_of_warranty+' => '',
	'Class:PhysicalDevice/Attribute:building_id' => 'Batiment',
	'Class:PhysicalDevice/Attribute:building_id+' => '',
	'Class:PhysicalDevice/Attribute:building_name' => 'Nom Batiment',
	'Class:PhysicalDevice/Attribute:building_name+' => '',
	'Class:PhysicalDevice/Attribute:floor_id' => 'Etage',
	'Class:PhysicalDevice/Attribute:floor_id+' => '',
	'Class:PhysicalDevice/Attribute:floor_name' => 'Nom Etage',
	'Class:PhysicalDevice/Attribute:floor_name+' => '',
	'Class:PhysicalDevice/Attribute:room_id' => 'Salle',
	'Class:PhysicalDevice/Attribute:room_id+' => '',
	'Class:PhysicalDevice/Attribute:room_name' => 'Nom salle',
	'Class:PhysicalDevice/Attribute:room_name+' => '',
	'Class:PhysicalDevice/Attribute:bay_id' => 'Baie',
	'Class:PhysicalDevice/Attribute:bay_id+' => '',
	'Class:PhysicalDevice/Attribute:bay_name' => 'Nom baie',
	'Class:PhysicalDevice/Attribute:bay_name+' => '',
));

//
// Class: DatacenterDevice
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DatacenterDevice' => 'Matériel Datacenter',
	'Class:DatacenterDevice+' => '',
	'Class:DatacenterDevice/Attribute:rack_id' => 'Rack',
	'Class:DatacenterDevice/Attribute:rack_id+' => '',
	'Class:DatacenterDevice/Attribute:rack_name' => 'Nom Rack',
	'Class:DatacenterDevice/Attribute:rack_name+' => '',
	'Class:DatacenterDevice/Attribute:enclosure_id' => 'Chassis',
	'Class:DatacenterDevice/Attribute:enclosure_id+' => '',
	'Class:DatacenterDevice/Attribute:enclosure_name' => 'Nom Chassis',
	'Class:DatacenterDevice/Attribute:enclosure_name+' => '',
	'Class:DatacenterDevice/Attribute:nb_u' => 'NB Unité',
	'Class:DatacenterDevice/Attribute:nb_u+' => '',
	'Class:DatacenterDevice/Attribute:managementip' => 'IP',
	'Class:DatacenterDevice/Attribute:managementip+' => '',
	'Class:DatacenterDevice/Attribute:powerA_id' => 'Source électrique A',
	'Class:DatacenterDevice/Attribute:powerA_id+' => '',
	'Class:DatacenterDevice/Attribute:powerA_name' => 'Nom Source électrique A',
	'Class:DatacenterDevice/Attribute:powerA_name+' => '',
	'Class:DatacenterDevice/Attribute:powerB_id' => 'Source électrique B',
	'Class:DatacenterDevice/Attribute:powerB_id+' => '',
	'Class:DatacenterDevice/Attribute:powerB_name' => 'Nom Source électrique B',
	'Class:DatacenterDevice/Attribute:powerB_name+' => '',
	'Class:DatacenterDevice/Attribute:fiberinterfacelist_list' => 'FC ports',
	'Class:DatacenterDevice/Attribute:fiberinterfacelist_list+' => '',
	'Class:DatacenterDevice/Attribute:san_list' => 'SANs',
	'Class:DatacenterDevice/Attribute:san_list+' => '',
	'Class:DatacenterDevice/Attribute:redundancy' => 'Redondance',
	'Class:DatacenterDevice/Attribute:redundancy+' => '',
));

//
// Class: Server
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Server' => 'Serveur',
	'Class:Server+' => '',
	'Class:Server/Attribute:osfamily_id' => 'Famille OS',
	'Class:Server/Attribute:osfamily_id+' => '',
	'Class:Server/Attribute:osfamily_name' => 'Nom Famille OS',
	'Class:Server/Attribute:osfamily_name+' => '',
	'Class:Server/Attribute:osversion_id' => 'Version OS',
	'Class:Server/Attribute:osversion_id+' => '',
	'Class:Server/Attribute:osversion_name' => 'Nom Version OS',
	'Class:Server/Attribute:osversion_name+' => '',
	'Class:Server/Attribute:oslicence_id' => 'Licence OS',
	'Class:Server/Attribute:oslicence_id+' => '',
	'Class:Server/Attribute:oslicence_name' => 'Nom Licence OS',
	'Class:Server/Attribute:oslicence_name+' => '',
	'Class:Server/Attribute:cpu' => 'CPU',
	'Class:Server/Attribute:cpu+' => '',
	'Class:Server/Attribute:ram' => 'RAM',
	'Class:Server/Attribute:ram+' => '',
	'Class:Server/Attribute:logicalvolumes_list' => 'Volumes logiques',
	'Class:Server/Attribute:logicalvolumes_list+' => '',
	'Class:Server/Attribute:service_list' => 'Services',
	'Class:Server/Attribute:service_list+' => '',
));

//
// Class: ApplicationSolution
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:ApplicationSolution' => 'Solution applicative',
	'Class:ApplicationSolution+' => '',
	'Class:ApplicationSolution/Attribute:functionalcis_list' => 'CIs',
	'Class:ApplicationSolution/Attribute:functionalcis_list+' => '',
	'Class:ApplicationSolution/Attribute:businessprocess_list' => 'Processus m\étiers',
	'Class:ApplicationSolution/Attribute:businessprocess_list+' => '',
	'Class:ApplicationSolution/Attribute:status' => 'Statut',
	'Class:ApplicationSolution/Attribute:status+' => '',
	'Class:ApplicationSolution/Attribute:status/Value:active' => 'active',
	'Class:ApplicationSolution/Attribute:status/Value:active+' => 'active',
	'Class:ApplicationSolution/Attribute:status/Value:inactive' => 'inactive',
	'Class:ApplicationSolution/Attribute:status/Value:inactive+' => 'inactive',
	'Class:ApplicationSolution/Attribute:redundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:redundancy+' => '',
	'Class:ApplicationSolution/Attribute:software_id' => 'logiciel',
	'Class:ApplicationSolution/Attribute:software_id+' => '',
	'Class:ApplicationSolution/Attribute:software_name' => 'Nom logiciel',
	'Class:ApplicationSolution/Attribute:software_name+' => '',
	'Class:ApplicationSolution/Attribute:softwarelicence_id' => 'Licence logiciel',
	'Class:ApplicationSolution/Attribute:softwarelicence_id+' => '',
	'Class:ApplicationSolution/Attribute:softwarelicence_name' => 'Nom Licence logiciel',
	'Class:ApplicationSolution/Attribute:softwarelicence_name+' => '',
	'Class:ApplicationSolution/Attribute:licencesoftware_list' => 'Logiciel de licence',
	'Class:ApplicationSolution/Attribute:licencesoftware_list+' => '',
	'Class:ApplicationSolution/Attribute:databaseschema_list' => 'Instance BDD',
	'Class:ApplicationSolution/Attribute:databaseschema_list+' => '',
	'Class:ApplicationSolution/Attribute:virtualmachine_list' => 'Hosts',
	'Class:ApplicationSolution/Attribute:virtualmachine_list+' => '',
	'Class:ApplicationSolution/Attribute:serversoftware_list' => 'Logiciel serveur d\'application',
	'Class:ApplicationSolution/Attribute:serversoftware_list+' => '',
	'Class:ApplicationSolution/Attribute:middlewareinstance_list' => 'Flux applicatif',
	'Class:ApplicationSolution/Attribute:middlewareinstance_list+' => '',
	'Class:ApplicationSolution/Attribute:databaseschemaredundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:databaseschemaredundancy+' => '',
	'Class:ApplicationSolution/Attribute:virtualmachineredundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:virtualmachineredundancy+' => '',
	'Class:ApplicationSolution/Attribute:serversoftwareredundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:serversoftwareredundancy+' => '',
	'Class:ApplicationSolution/Attribute:middlewareinstanceredundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:middlewareinstanceredundancy+' => '',
	'Class:ApplicationSolution/Attribute:licenceredundancy' => 'Analyse d\'impact : configuration de la redondance',
	'Class:ApplicationSolution/Attribute:licenceredundancy+' => '',
	'Class:ApplicationSolution/Attribute:service_list' => 'Services',
	'Class:ApplicationSolution/Attribute:service_list+' => '',
));

//
// Class: BusinessProcess
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:BusinessProcess' => 'Processus métier',
	'Class:BusinessProcess+' => '',
	'Class:BusinessProcess/Attribute:applicationsolutions_list' => 'Solutions applicatives',
	'Class:BusinessProcess/Attribute:applicationsolutions_list+' => '',
	'Class:BusinessProcess/Attribute:status' => 'Statut',
	'Class:BusinessProcess/Attribute:status+' => '',
	'Class:BusinessProcess/Attribute:status/Value:active' => 'actif',
	'Class:BusinessProcess/Attribute:status/Value:active+' => 'actif',
	'Class:BusinessProcess/Attribute:status/Value:inactive' => 'inactif',
	'Class:BusinessProcess/Attribute:status/Value:inactive+' => 'inactif',
	'Class:BusinessProcess/Attribute:pcsoftware_list' => 'Logiciel PC',
	'Class:BusinessProcess/Attribute:pcsoftware_list+' => '',
	'Class:BusinessProcess/Attribute:deportedconsol_list' => 'Console d\éport\ée',
	'Class:BusinessProcess/Attribute:deportedconsol_list+' => '',
	'Class:BusinessProcess/Attribute:service_list' => 'Services',
	'Class:BusinessProcess/Attribute:service_list+' => '',
));

//
// Class: SoftwareInstance
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:SoftwareInstance' => 'Instance logiciel',
	'Class:SoftwareInstance+' => '',
	'Class:SoftwareInstance/Attribute:system_id' => 'Système',
	'Class:SoftwareInstance/Attribute:system_id+' => '',
	'Class:SoftwareInstance/Attribute:system_name' => 'Nom du système',
	'Class:SoftwareInstance/Attribute:system_name+' => '',
	'Class:SoftwareInstance/Attribute:software_id' => 'Logiciel',
	'Class:SoftwareInstance/Attribute:software_id+' => '',
	'Class:SoftwareInstance/Attribute:software_name' => 'Nom du logiciel',
	'Class:SoftwareInstance/Attribute:software_name+' => '',
	'Class:SoftwareInstance/Attribute:softwarelicence_id' => 'Licence logiciel',
	'Class:SoftwareInstance/Attribute:softwarelicence_id+' => '',
	'Class:SoftwareInstance/Attribute:softwarelicence_name' => 'Nom Licence logiciel',
	'Class:SoftwareInstance/Attribute:softwarelicence_name+' => '',
	'Class:SoftwareInstance/Attribute:path' => 'Chemin d`installation',
	'Class:SoftwareInstance/Attribute:path+' => '',
	'Class:SoftwareInstance/Attribute:status' => 'Statut',
	'Class:SoftwareInstance/Attribute:status+' => '',
	'Class:SoftwareInstance/Attribute:status/Value:active' => 'actif',
	'Class:SoftwareInstance/Attribute:status/Value:active+' => '',
	'Class:SoftwareInstance/Attribute:status/Value:inactive' => 'inactif',
	'Class:SoftwareInstance/Attribute:status/Value:inactive+' => '',
	'Class:SoftwareInstance/Attribute:deploymentpackage_list' => 'Package de déploiement',
	'Class:SoftwareInstance/Attribute:deploymentpackage_list+' => '',
));

//
// Class: Middleware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Middleware' => 'Middleware',
	'Class:Middleware+' => '',
	'Class:Middleware/Attribute:middlewareinstance_list' => 'Instance Middleware',
	'Class:Middleware/Attribute:middlewareinstance_list+' => '',
	'Class:Middleware/Attribute:service_list' => 'Services',
	'Class:Middleware/Attribute:service_list+' => '',
));

//
// Class: DBServer
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DBServer' => 'Moteur SGBD',
	'Class:DBServer+' => '',
	'Class:DBServer/Attribute:dbschema_list' => 'Instances de base de données',
	'Class:DBServer/Attribute:dbschema_list+' => '',
	'Class:DBServer/Attribute:dbcluster_id' => 'Moteur cluster SGBD',
	'Class:DBServer/Attribute:dbcluster_id+' => '',
	'Class:DBServer/Attribute:dbcluster_name' => 'Nom Moteur cluster SGBD',
	'Class:DBServer/Attribute:dbcluster_name+' => '',
	'Class:DBServer/Attribute:service_list' => 'Services',
	'Class:DBServer/Attribute:service_list+' => '',
));

//
// Class: WebServer
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:WebServer' => 'Serveur Web',
	'Class:WebServer+' => '',
	'Class:WebServer/Attribute:webapp_list' => 'Application Web',
	'Class:WebServer/Attribute:webapp_list+' => '',
	'Class:WebServer/Attribute:service_list' => 'Services',
	'Class:WebServer/Attribute:service_list+' => '',
));

//
// Class: PCSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:PCSoftware' => 'Logiciel PC',
	'Class:PCSoftware+' => '',
	'Class:PCSoftware/Attribute:service_list' => 'Services',
	'Class:PCSoftware/Attribute:service_list+' => '',
));

//
// Class: OtherSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:OtherSoftware' => 'Autre logiciel',
	'Class:OtherSoftware+' => '',
));

//
// Class: MiddlewareInstance
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:MiddlewareInstance' => 'Instance Middleware',
	'Class:MiddlewareInstance+' => '',
	'Class:MiddlewareInstance/Attribute:middleware_id' => 'Middleware',
	'Class:MiddlewareInstance/Attribute:middleware_id+' => '',
	'Class:MiddlewareInstance/Attribute:middleware_name' => 'Nom Middleware',
	'Class:MiddlewareInstance/Attribute:middleware_name+' => '',
	'Class:MiddlewareInstance/Attribute:applicationsol_list' => 'applicationsol list',
	'Class:MiddlewareInstance/Attribute:applicationsol_list+' => '',
	'Class:MiddlewareInstance/Attribute:service_list' => 'Services',
	'Class:MiddlewareInstance/Attribute:service_list+' => '',
));

//
// Class: DatabaseSchema
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DatabaseSchema' => 'Instance de base de données',
	'Class:DatabaseSchema+' => '',
	'Class:DatabaseSchema/Attribute:dbserver_id' => 'Serveur de base de données',
	'Class:DatabaseSchema/Attribute:dbserver_id+' => '',
	'Class:DatabaseSchema/Attribute:dbserver_name' => 'Nom Serveur de base de données',
	'Class:DatabaseSchema/Attribute:dbserver_name+' => '',
	'Class:DatabaseSchema/Attribute:applicationsol_list' => 'Solution applicative',
	'Class:DatabaseSchema/Attribute:applicationsol_list+' => '',
	'Class:DatabaseSchema/Attribute:service_list' => 'Services',
	'Class:DatabaseSchema/Attribute:service_list+' => '',
));

//
// Class: WebApplication
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:WebApplication' => 'Application Web',
	'Class:WebApplication+' => '',
	'Class:WebApplication/Attribute:webserver_id' => 'Serveur Web',
	'Class:WebApplication/Attribute:webserver_id+' => '',
	'Class:WebApplication/Attribute:webserver_name' => 'Nom Serveur Web',
	'Class:WebApplication/Attribute:webserver_name+' => '',
	'Class:WebApplication/Attribute:url' => 'URL',
	'Class:WebApplication/Attribute:url+' => '',
));

//
// Class: Software
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Software' => 'Logiciel',
	'Class:Software+' => '',
	'Class:Software/Attribute:name' => 'Nom',
	'Class:Software/Attribute:name+' => '',
	'Class:Software/Attribute:vendor' => 'Vendeur',
	'Class:Software/Attribute:vendor+' => '',
	'Class:Software/Attribute:version' => 'Version',
	'Class:Software/Attribute:version+' => '',
	'Class:Software/Attribute:documents_list' => 'Documents',
	'Class:Software/Attribute:documents_list+' => '',
	'Class:Software/Attribute:type' => 'Type',
	'Class:Software/Attribute:type+' => '',
	'Class:Software/Attribute:type/Value:ApplicationSolution' => 'ApplicationSolution',
	'Class:Software/Attribute:type/Value:ApplicationSolution+' => 'ApplicationSolution',
	'Class:Software/Attribute:type/Value:DBCluster' => 'DBCluster',
	'Class:Software/Attribute:type/Value:DBCluster+' => 'DBCluster',
	'Class:Software/Attribute:type/Value:DBServer' => 'Serveur de base de données',
	'Class:Software/Attribute:type/Value:DBServer+' => 'Serveur de base de données',
	'Class:Software/Attribute:type/Value:DeportedConsol' => 'DeportedConsol',
	'Class:Software/Attribute:type/Value:DeportedConsol+' => 'DeportedConsol',
	'Class:Software/Attribute:type/Value:LicenceSoftware' => 'LicenceSoftware',
	'Class:Software/Attribute:type/Value:LicenceSoftware+' => 'LicenceSoftware',
	'Class:Software/Attribute:type/Value:Middleware' => 'Middleware',
	'Class:Software/Attribute:type/Value:Middleware+' => 'Middleware',
	'Class:Software/Attribute:type/Value:OtherSoftware' => 'Autre logiciel',
	'Class:Software/Attribute:type/Value:OtherSoftware+' => 'Autre logiciel',
	'Class:Software/Attribute:type/Value:PCSoftware' => 'Logiciel PC',
	'Class:Software/Attribute:type/Value:PCSoftware+' => 'Logiciel PC',
	'Class:Software/Attribute:type/Value:ServerSoftware' => 'ServerSoftware',
	'Class:Software/Attribute:type/Value:ServerSoftware+' => 'ServerSoftware',
	'Class:Software/Attribute:type/Value:WebServer' => 'Serveur Web',
	'Class:Software/Attribute:type/Value:WebServer+' => 'Serveur Web',
	'Class:Software/Attribute:type/Value:backupSoftware' => 'backupSoftware',
	'Class:Software/Attribute:type/Value:backupSoftware+' => 'backupSoftware',
	'Class:Software/Attribute:softwareinstance_list' => 'Instances logiciels',
	'Class:Software/Attribute:softwareinstance_list+' => '',
	'Class:Software/Attribute:softwarepatch_list' => 'Patchs logiciels',
	'Class:Software/Attribute:softwarepatch_list+' => '',
	'Class:Software/Attribute:softwarelicence_list' => 'Software licences',
	'Class:Software/Attribute:softwarelicence_list+' => '',
	'Class:Software/Attribute:vendor_name' => 'Nom',
	'Class:Software/Attribute:vendor_name+' => '',
));

//
// Class: OSVersion
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:OSVersion' => 'Version OS',
	'Class:OSVersion+' => '',
	'Class:OSVersion/Attribute:osfamily_id' => 'Famille OS',
	'Class:OSVersion/Attribute:osfamily_id+' => '',
	'Class:OSVersion/Attribute:osfamily_name' => 'Nom Famille OS',
	'Class:OSVersion/Attribute:osfamily_name+' => '',
	'Class:OSVersion/Attribute:Server_list' => 'Servers',
	'Class:OSVersion/Attribute:Server_list+' => '',
	'Class:OSVersion/Attribute:Host_list' => 'Hosts',
	'Class:OSVersion/Attribute:Host_list+' => '',
	'Class:OSVersion/Attribute:PC_list' => 'PC',
	'Class:OSVersion/Attribute:PC_list+' => '',
	'Class:OSVersion/Attribute:Licence_list' => 'Licences',
	'Class:OSVersion/Attribute:Licence_list+' => '',
));

//
// Class: OSFamily
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:OSFamily' => 'Famille OS',
	'Class:OSFamily+' => '',
	'Class:OSFamily/Attribute:OSversion_list' => 'Version d\'OS',
	'Class:OSFamily/Attribute:OSversion_list+' => '',
));

//
// Class: Rack
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Rack' => 'Rack',
	'Class:Rack+' => '',
	'Class:Rack/Attribute:nb_u' => 'NB Unité',
	'Class:Rack/Attribute:nb_u+' => '',
	'Class:Rack/Attribute:device_list' => 'Matériels',
	'Class:Rack/Attribute:device_list+' => '',
	'Class:Rack/Attribute:enclosure_list' => 'Chassis',
	'Class:Rack/Attribute:enclosure_list+' => '',
	'Class:Rack/Attribute:service_list' => 'Services',
	'Class:Rack/Attribute:service_list+' => '',
));

//
// Class: PC
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:PC' => 'PC',
	'Class:PC+' => '',
	'Class:PC/Attribute:osfamily_id' => 'Famille OS',
	'Class:PC/Attribute:osfamily_id+' => '',
	'Class:PC/Attribute:osfamily_name' => 'Nom Famille OS',
	'Class:PC/Attribute:osfamily_name+' => '',
	'Class:PC/Attribute:osversion_id' => 'Version OS',
	'Class:PC/Attribute:osversion_id+' => '',
	'Class:PC/Attribute:osversion_name' => 'Nom Version OS',
	'Class:PC/Attribute:osversion_name+' => '',
	'Class:PC/Attribute:cpu' => 'CPU',
	'Class:PC/Attribute:cpu+' => '',
	'Class:PC/Attribute:ram' => 'RAM',
	'Class:PC/Attribute:ram+' => '',
	'Class:PC/Attribute:type' => 'Type',
	'Class:PC/Attribute:type+' => '',
	'Class:PC/Attribute:type/Value:desktop' => 'desktop',
	'Class:PC/Attribute:type/Value:desktop+' => 'desktop',
	'Class:PC/Attribute:type/Value:laptop' => 'laptop',
	'Class:PC/Attribute:type/Value:laptop+' => 'laptop',
	'Class:PC/Attribute:service_list' => 'Services',
	'Class:PC/Attribute:service_list+' => '',
));

//
// Class: Printer
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Printer' => 'Imprimante',
	'Class:Printer+' => '',
	'Class:Printer/Attribute:service_list' => 'Services',
	'Class:Printer/Attribute:service_list+' => '',
));

//
// Class: TelephonyCI
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:TelephonyCI' => 'CI Téléphonie',
	'Class:TelephonyCI+' => '',
	'Class:TelephonyCI/Attribute:phonenumber' => 'Numéro',
	'Class:TelephonyCI/Attribute:phonenumber+' => '',
	'Class:TelephonyCI/Attribute:service_list' => 'Services',
	'Class:TelephonyCI/Attribute:service_list+' => '',
));

//
// Class: Phone
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Phone' => 'Téléphone',
	'Class:Phone+' => '',
));

//
// Class: MobilePhone
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:MobilePhone' => 'Téléphone mobile',
	'Class:MobilePhone+' => '',
	'Class:MobilePhone/Attribute:imei' => 'IMEI',
	'Class:MobilePhone/Attribute:imei+' => '',
	'Class:MobilePhone/Attribute:hw_pin' => 'PIN',
	'Class:MobilePhone/Attribute:hw_pin+' => '',
));

//
// Class: IPPhone
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:IPPhone' => 'Téléphone IP',
	'Class:IPPhone+' => '',
));

//
// Class: Tablet
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Tablet' => 'Tablette',
	'Class:Tablet+' => '',
	'Class:Tablet/Attribute:service_list' => 'Services',
	'Class:Tablet/Attribute:service_list+' => '',
));

//
// Class: Peripheral
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Peripheral' => 'Périphérique',
	'Class:Peripheral+' => '',
	'Class:Peripheral/Attribute:service_list' => 'Services',
	'Class:Peripheral/Attribute:service_list+' => '',
));

//
// Class: StorageSystem
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:StorageSystem' => 'Système de stockage',
	'Class:StorageSystem+' => '',
	'Class:StorageSystem/Attribute:logicalvolume_list' => 'Volumes logiques',
	'Class:StorageSystem/Attribute:logicalvolume_list+' => '',
	'Class:StorageSystem/Attribute:service_list' => 'Services',
	'Class:StorageSystem/Attribute:service_list+' => '',
));


//
// Class: TapeLibrary
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:TapeLibrary' => 'Bandothèque',
	'Class:TapeLibrary+' => '',
	'Class:TapeLibrary/Attribute:tapes_list' => 'Bandes',
	'Class:TapeLibrary/Attribute:tapes_list+' => '',
	'Class:TapeLibrary/Attribute:service_list' => 'Services',
	'Class:TapeLibrary/Attribute:service_list+' => '',
));

//
// Class: NAS
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:NAS' => 'NAS',
	'Class:NAS+' => '',
	'Class:NAS/Attribute:nasfilesystem_list' => 'Systèmes de fichier NAS',
	'Class:NAS/Attribute:nasfilesystem_list+' => '',
	'Class:NAS/Attribute:service_list' => 'Services',
	'Class:NAS/Attribute:service_list+' => '',
));

//
// Class: Farm
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Farm' => 'vCluster',
	'Class:Farm+' => '',
	'Class:Farm/Attribute:hypervisor_list' => 'Hyperviseurs',
	'Class:Farm/Attribute:hypervisor_list+' => '',
	'Class:Farm/Attribute:redundancy' => 'Haute disponibilité',
	'Class:Farm/Attribute:redundancy+' => '',
	'Class:Farm/Attribute:service_list' => 'Services',
	'Class:Farm/Attribute:service_list+' => '',
));

//
// Class: VirtualMachine
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:VirtualMachine' => 'Machine Virtuelle',
	'Class:VirtualMachine+' => '',
	'Class:VirtualMachine/Attribute:virtualhost_id' => 'vCluster / Hyperviseur',
	'Class:VirtualMachine/Attribute:virtualhost_id+' => '',
	'Class:VirtualMachine/Attribute:virtualhost_name' => 'Nom Host',
	'Class:VirtualMachine/Attribute:virtualhost_name+' => '',
	'Class:VirtualMachine/Attribute:osfamily_id' => 'Famille OS',
	'Class:VirtualMachine/Attribute:osfamily_id+' => '',
	'Class:VirtualMachine/Attribute:osfamily_name' => 'Nom Famille OS',
	'Class:VirtualMachine/Attribute:osfamily_name+' => '',
	'Class:VirtualMachine/Attribute:osversion_id' => 'Version OS',
	'Class:VirtualMachine/Attribute:osversion_id+' => '',
	'Class:VirtualMachine/Attribute:osversion_name' => 'Nom Version OS',
	'Class:VirtualMachine/Attribute:osversion_name+' => '',
	'Class:VirtualMachine/Attribute:oslicence_id' => 'Licence OS',
	'Class:VirtualMachine/Attribute:oslicence_id+' => '',
	'Class:VirtualMachine/Attribute:oslicence_name' => 'Nom Licence OS',
	'Class:VirtualMachine/Attribute:oslicence_name+' => '',
	'Class:VirtualMachine/Attribute:cpu' => 'CPU',
	'Class:VirtualMachine/Attribute:cpu+' => '',
	'Class:VirtualMachine/Attribute:ram' => 'RAM',
	'Class:VirtualMachine/Attribute:ram+' => '',
	'Class:VirtualMachine/Attribute:logicalinterface_list' => 'Interfaces réseaux',
	'Class:VirtualMachine/Attribute:logicalinterface_list+' => '',
	'Class:VirtualMachine/Attribute:managementip' => 'IP',
	'Class:VirtualMachine/Attribute:managementip+' => '',
	'Class:VirtualMachine/Attribute:nasfilesystem_id' => 'Systèmes de fichier',
	'Class:VirtualMachine/Attribute:nasfilesystem_id+' => '',
	'Class:VirtualMachine/Attribute:nasfilesystem_name' => 'Nom Systèmes de fichier',
	'Class:VirtualMachine/Attribute:nasfilesystem_name+' => '',
	'Class:VirtualMachine/Attribute:applicationsol_list' => 'Solution Applicative',
	'Class:VirtualMachine/Attribute:applicationsol_list+' => '',
	'Class:VirtualMachine/Attribute:service_list' => 'Services',
	'Class:VirtualMachine/Attribute:service_list+' => '',
));


//
// Class: LogicalVolume
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:LogicalVolume' => 'Volume logique',
	'Class:LogicalVolume+' => '',
	'Class:LogicalVolume/Attribute:name' => 'Nom',
	'Class:LogicalVolume/Attribute:name+' => '',
	'Class:LogicalVolume/Attribute:lun_id' => 'LUN ID',
	'Class:LogicalVolume/Attribute:lun_id+' => '',
	'Class:LogicalVolume/Attribute:description' => 'Description',
	'Class:LogicalVolume/Attribute:description+' => '',
	'Class:LogicalVolume/Attribute:raid_level' => 'Niveau RAID',
	'Class:LogicalVolume/Attribute:raid_level+' => '',
	'Class:LogicalVolume/Attribute:size' => 'Taille',
	'Class:LogicalVolume/Attribute:size+' => '',
	'Class:LogicalVolume/Attribute:storagesystem_id' => 'Système de stockage',
	'Class:LogicalVolume/Attribute:storagesystem_id+' => '',
	'Class:LogicalVolume/Attribute:storagesystem_name' => 'Nom Système de stockage',
	'Class:LogicalVolume/Attribute:storagesystem_name+' => '',
	'Class:LogicalVolume/Attribute:servers_list' => 'Serveurs',
	'Class:LogicalVolume/Attribute:servers_list+' => '',
	'Class:LogicalVolume/Attribute:virtualdevices_list' => 'Hosts',
	'Class:LogicalVolume/Attribute:virtualdevices_list+' => '',
));

//
// Class: VirtualHost
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:VirtualHost' => 'Hôte Virtuel',
	'Class:VirtualHost+' => '',
	'Class:VirtualHost/Attribute:virtualmachine_list' => 'Hosts',
	'Class:VirtualHost/Attribute:virtualmachine_list+' => '',
));

//
// Class: Hypervisor
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Hypervisor' => 'Hyperviseur',
	'Class:Hypervisor+' => '',
	'Class:Hypervisor/Attribute:farm_id' => 'vCluster',
	'Class:Hypervisor/Attribute:farm_id+' => '',
	'Class:Hypervisor/Attribute:farm_name' => 'Nom vCluster',
	'Class:Hypervisor/Attribute:farm_name+' => '',
	'Class:Hypervisor/Attribute:server_id' => 'Serveur',
	'Class:Hypervisor/Attribute:server_id+' => '',
	'Class:Hypervisor/Attribute:server_name' => 'Nom serveur',
	'Class:Hypervisor/Attribute:server_name+' => '',
	'Class:Hypervisor/Attribute:service_list' => 'Services',
	'Class:Hypervisor/Attribute:service_list+' => '',
));


//
// Class: LogicalInterface
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:LogicalInterface' => 'Interface logique',
	'Class:LogicalInterface+' => '',
	'Class:LogicalInterface/Attribute:virtualmachine_id' => 'Host',
	'Class:LogicalInterface/Attribute:virtualmachine_id+' => '',
	'Class:LogicalInterface/Attribute:virtualmachine_name' => 'Nom Host',
	'Class:LogicalInterface/Attribute:virtualmachine_name+' => '',
));

//
// Class: Building
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Building' => 'Batiment',
	'Class:Building+' => '',
	'Class:Building/Attribute:location_id' => 'Site',
	'Class:Building/Attribute:location_id+' => '',
	'Class:Building/Attribute:location_name' => 'Nom site',	
	'Class:Building/Attribute:location_name+' => '',
));

//
// Class: Floor
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Floor' => 'Etage',
	'Class:Floor+' => '',
	'Class:Floor/Attribute:building_id' => 'Batiment',
	'Class:Floor/Attribute:building_id+' => '',
	'Class:Floor/Attribute:building_name' => 'Nom Batiment',
	'Class:Floor/Attribute:building_name+' => '',
));

//
// Class: Room
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Room' => 'Salle',
	'Class:Room+' => '',
	'Class:Room/Attribute:floor_id' => 'Etage',
	'Class:Room/Attribute:floor_id+' => '',
	'Class:Room/Attribute:floor_name' => 'Nom Etage',
	'Class:Room/Attribute:floor_name+' => '',
));

//
// Class: Bay
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Bay' => 'Baie',
	'Class:Bay+' => '',
	'Class:Bay/Attribute:room_id' => 'Salle',
	'Class:Bay/Attribute:room_id+' => '',
	'Class:Bay/Attribute:room_name' => 'Nom Salle',
	'Class:Bay/Attribute:room_name+' => '',
));

//
// Class: Cooling
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Cooling' => 'Refroidissement',
	'Class:Cooling+' => '',
	'Class:Cooling/Attribute:averagetemp' => 'Température moyenne',
	'Class:Cooling/Attribute:averagetemp+' => '',
	'Class:Cooling/Attribute:averagehumidity' => 'Humidité moyenne',
	'Class:Cooling/Attribute:averagehumidity+' => '',
	'Class:Cooling/Attribute:type' => 'type',
	'Class:Cooling/Attribute:type+' => '',
	'Class:Cooling/Attribute:type/Value:Aircooling' => 'Aircooling',
	'Class:Cooling/Attribute:type/Value:Aircooling+' => 'Aircooling',
	'Class:Cooling/Attribute:type/Value:Watercooling' => 'Watercooling',
	'Class:Cooling/Attribute:type/Value:Watercooling+' => 'Watercooling',
	'Class:Cooling/Attribute:rack_list' => 'Liste des racks',
	'Class:Cooling/Attribute:rack_list+' => '',
	'Class:Cooling/Attribute:service_list' => 'Services',
	'Class:Cooling/Attribute:service_list+' => '',
));

//
// Class: LicenceSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:LicenceSoftware' => 'Logiciel serveur de licence',
	'Class:LicenceSoftware+' => '',
	'Class:LicenceSoftware/Attribute:applicationsol_list' => 'Solution applicative',
	'Class:LicenceSoftware/Attribute:applicationsol_list+' => '',
	'Class:LicenceSoftware/Attribute:service_list' => 'Services',
	'Class:LicenceSoftware/Attribute:service_list+' => '',
));

//
// Class: ServerSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:ServerSoftware' => 'Logiciel serveur d\'application',
	'Class:ServerSoftware+' => '',
	'Class:ServerSoftware/Attribute:applicationsol_list' => 'Solution applicative',
	'Class:ServerSoftware/Attribute:applicationsol_list+' => '',
	'Class:ServerSoftware/Attribute:service_list' => 'Services',
	'Class:ServerSoftware/Attribute:service_list+' => '',
));

//
// Class: backupSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:backupSoftware' => 'Logiciel serveur de sauvegarde',
	'Class:backupSoftware+' => '',
));

//
// Class: DBCluster
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DBCluster' => 'Moteur cluster SGBD',
	'Class:DBCluster+' => '',
	'Class:DBCluster/Attribute:dbserver_list' => 'liste des moeteurs SGBD',
	'Class:DBCluster/Attribute:dbserver_list+' => '',
	'Class:DBCluster/Attribute:redundancy' => 'Redondance',
	'Class:DBCluster/Attribute:redundancy+' => '',
	'Class:DBCluster/Attribute:service_list' => 'Services',
	'Class:DBCluster/Attribute:service_list+' => '',
));

//
// Class: DeportedConsol
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DeportedConsol' => 'Console déportée',
	'Class:DeportedConsol+' => '',
	'Class:DeportedConsol/Attribute:service_list' => 'Services',
	'Class:DeportedConsol/Attribute:service_list+' => '',
));

//
// Class: DeploymentPackage
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:DeploymentPackage' => 'Package de déploiement',
	'Class:DeploymentPackage+' => '',
	'Class:DeploymentPackage/Attribute:package_list' => 'Packages',
	'Class:DeploymentPackage/Attribute:package_list+' => '',
	'Class:DeploymentPackage/Attribute:softwareinstance_list' => 'Instance logiciel',
	'Class:DeploymentPackage/Attribute:softwareinstance_list+' => '',
	'Class:DeploymentPackage/Attribute:status' => 'Statut',
	'Class:DeploymentPackage/Attribute:status+' => '',
	'Class:DeploymentPackage/Attribute:status/Value:active' => 'active',
	'Class:DeploymentPackage/Attribute:status/Value:active+' => 'active',
	'Class:DeploymentPackage/Attribute:status/Value:inactive' => 'inactive',
	'Class:DeploymentPackage/Attribute:status/Value:inactive+' => 'inactive',
));

//
// Class: Package
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:Package' => 'Package',
	'Class:Package+' => '',
	'Class:Package/Attribute:name' => 'Nom',
	'Class:Package/Attribute:name+' => '',
	'Class:Package/Attribute:version' => 'version',
	'Class:Package/Attribute:version+' => '',
	'Class:Package/Attribute:documents_list' => 'Documents',
	'Class:Package/Attribute:documents_list+' => '',
	'Class:Package/Attribute:type' => 'type',
	'Class:Package/Attribute:type+' => '',
	'Class:Package/Attribute:type/Value:PackageApplicatif' => 'Package Applicatif',
	'Class:Package/Attribute:type/Value:PackageApplicatif+' => 'Package Applicatif',
	'Class:Package/Attribute:type/Value:PackageDeConfiguration' => 'Package De Configuration',
	'Class:Package/Attribute:type/Value:PackageDeConfiguration+' => 'Package De Configuration',
	'Class:Package/Attribute:type/Value:PackageVM' => 'Package VM',
	'Class:Package/Attribute:type/Value:PackageVM+' => 'Package VM',
	'Class:Package/Attribute:deploymentpackage_list' => 'Packages de déploiement',
	'Class:Package/Attribute:deploymentpackage_list+' => '',
));

//
// Class: lnkPackageToDeploymentPackage
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkPackageToDeploymentPackage' => 'Lien Package / Package de déploiement ',
	'Class:lnkPackageToDeploymentPackage+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_id' => 'Package de déploiement',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_id+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_name' => 'Nom package de déploiement',
	'Class:lnkPackageToDeploymentPackage/Attribute:deploymentpackage_name+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_id' => 'Package',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_id+' => '',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_name' => 'Nom Package',
	'Class:lnkPackageToDeploymentPackage/Attribute:package_name+' => '',
));

//
// Class: lnkRackToCooling
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkRackToCooling' => 'Lien Rack / Cooling',
	'Class:lnkRackToCooling+' => '',
	'Class:lnkRackToCooling/Attribute:rack_id' => 'Rack',
	'Class:lnkRackToCooling/Attribute:rack_id+' => '',
	'Class:lnkRackToCooling/Attribute:rack_name' => 'Nom Rack',
	'Class:lnkRackToCooling/Attribute:rack_name+' => '',
	'Class:lnkRackToCooling/Attribute:cooling_id' => 'Refroidissement',
	'Class:lnkRackToCooling/Attribute:cooling_id+' => '',
	'Class:lnkRackToCooling/Attribute:cooling_name' => 'Nom Refroidissement',
	'Class:lnkRackToCooling/Attribute:cooling_name+' => '',
));

//
// Class: lnkApplicationSolutionToLicenceSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkApplicationSolutionToLicenceSoftware' => 'Lien Solution applicative / Logiciel serveur de licence',
	'Class:lnkApplicationSolutionToLicenceSoftware+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_id' => 'Solution applicative',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_name' => 'Nom Solution applicative',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_id' => 'Logiciel serveur de licence',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_id+' => '',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_name' => 'Nom Logiciel serveur de licence',
	'Class:lnkApplicationSolutionToLicenceSoftware/Attribute:licencesoftware_name+' => '',
));

//
// Class: lnkApplicationSolutionToDatabaseSchema
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkApplicationSolutionToDatabaseSchema' => 'Lien Solution applicative / Instance BDD',
	'Class:lnkApplicationSolutionToDatabaseSchema+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_id' => 'Solution applicative',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_name' => 'Nom Solution applicative',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_id' => 'Instance BDD',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_id+' => '',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_name' => 'Nom Instance BDD',
	'Class:lnkApplicationSolutionToDatabaseSchema/Attribute:databaseschema_name+' => '',
));

//
// Class: lnkApplicationSolutionToVirtualMachine
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkApplicationSolutionToVirtualMachine' => 'Lien Solution applicative / Host',
	'Class:lnkApplicationSolutionToVirtualMachine+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_id' => 'Solution applicative',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_name' => 'Nom Solution applicative',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_id' => 'Host',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_id+' => '',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_name' => 'Nom Host',
	'Class:lnkApplicationSolutionToVirtualMachine/Attribute:virtualmachine_name+' => '',
));

//
// Class: lnkApplicationSolutionToServerSoftware
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkApplicationSolutionToServerSoftware' => 'Lien Solution applicative / Logiciel serveur d\'application',
	'Class:lnkApplicationSolutionToServerSoftware+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_id' => 'Solution applicative',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_name' => 'Nom Solution applicative',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_id' => 'Logiciel serveur d\'application',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_id+' => '',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_name' => 'Nom Logiciel serveur d\'application',
	'Class:lnkApplicationSolutionToServerSoftware/Attribute:serversoftware_name+' => '',
));

//
// Class: lnkApplicationSolutionToMiddlewareInstance
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkApplicationSolutionToMiddlewareInstance' => 'Lien Solution applicative / Flux applicatif',
	'Class:lnkApplicationSolutionToMiddlewareInstance+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_id' => 'Solution applicative',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_id+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_name' => 'Nom Solution applicative',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:applicationsolution_name+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_id' => 'Flux applicatif',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_id+' => '',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_name' => 'Nom Flux applicatif',
	'Class:lnkApplicationSolutionToMiddlewareInstance/Attribute:middlewareinstance_name+' => '',
));

//
// Class: lnkSoftwareInstanceToDeploymentPackage
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkSoftwareInstanceToDeploymentPackage' => 'Link Software instance / Deployment package',
	'Class:lnkSoftwareInstanceToDeploymentPackage+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_id' => 'Instance logiciel',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_id+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_name' => 'Nom Instance logiciel',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:softwareinstance_name+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_id' => 'Package de déploiement',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_id+' => '',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_name' => 'Nom Package de déploiement',
	'Class:lnkSoftwareInstanceToDeploymentPackage/Attribute:deploymentpackage_name+' => '',
));

//
// Class: lnkPCSoftwareToBusinessProcess
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkPCSoftwareToBusinessProcess' => 'Lien Logiciel PC / Processus métier',
	'Class:lnkPCSoftwareToBusinessProcess+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_id' => 'Processus métier',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_id+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_name' => 'Nom Processus métier',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:businessprocess_name+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_id' => 'Logiciel PC',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_id+' => '',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_name' => 'Nom Logiciel PC',
	'Class:lnkPCSoftwareToBusinessProcess/Attribute:pcsoftware_name+' => '',
));

//
// Class: lnkDeportedConsolToBusinessProcess
//

Dict::Add('FR FR', 'French', 'Français', array(
	'Class:lnkDeportedConsolToBusinessProcess' => 'Lien Contsole déportée / Processus métier',
	'Class:lnkDeportedConsolToBusinessProcess+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_id' => 'Processus métier',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_id+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_name' => 'Nom Processus métier',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:businessprocess_name+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_id' => 'Console déportée',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_id+' => '',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_name' => 'Nom Console déportée',
	'Class:lnkDeportedConsolToBusinessProcess/Attribute:deportedconsol_name+' => '',
));


?>
